#include "backward.cuh"
#include "bindings.h"
#include "forward.cuh"
#include "helpers.cuh"
#include <cooperative_groups.h>
#include <cooperative_groups/reduce.h>
#include <cstdio>
#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_runtime_api.h>
#include <iostream>
#include <math.h>
#include <torch/extension.h>
#include <tuple>

namespace cg = cooperative_groups;

__global__ void compute_cov2d_bounds_kernel(
    const unsigned num_pts, const float* __restrict__ covs2d,
    const float* __restrict__ opacities, float* __restrict__ conics, float2* __restrict__ extents
) {
    unsigned row = cg::this_grid().thread_rank();
    if (row >= num_pts) {
        return;
    }
    int index = row * 3;
    float3 conic;
    float2 extent;
    float3 cov2d{
        (float)covs2d[index], (float)covs2d[index + 1], (float)covs2d[index + 2]
    };
    float opacity = opacities ? opacities[row] : 1.0f;
    compute_cov2d_bounds(cov2d, opacity, conic, extent);
    conics[index] = conic.x;
    conics[index + 1] = conic.y;
    conics[index + 2] = conic.z;
    extents[row] = extent;
}

std::tuple<
    torch::Tensor, // output conics
    torch::Tensor> // output extents
compute_cov2d_bounds_tensor(
    const int num_pts,
    torch::Tensor &covs2d,
    const c10::optional<torch::Tensor> &opacities) {
    DEVICE_GUARD(covs2d);
    CHECK_INPUT(covs2d);
    torch::Tensor conics = torch::zeros(
        {num_pts, covs2d.size(1)}, covs2d.options().dtype(torch::kFloat32)
    );
    torch::Tensor extents =
        torch::zeros({num_pts, 2}, covs2d.options().dtype(torch::kFloat32));

    int blocks = (num_pts + N_THREADS - 1) / N_THREADS;

    compute_cov2d_bounds_kernel<<<blocks, N_THREADS>>>(
        num_pts,
        covs2d.contiguous().data_ptr<float>(),
        opacities.has_value() ? opacities.value().contiguous().data_ptr<float>() : nullptr,
        conics.contiguous().data_ptr<float>(),
        (float2*)extents.contiguous().data_ptr<float>()
    );
    return std::make_tuple(conics, extents);
}

std::tuple<
    torch::Tensor,
    torch::Tensor,
    torch::Tensor,
    torch::Tensor>
project_gaussians_forward_tensor(
    const int num_points,
    torch::Tensor &cov2d,
    torch::Tensor &means2d,
    const c10::optional<torch::Tensor> &opacities,
    const unsigned img_height,
    const unsigned img_width,
    const unsigned block_width
) {
    DEVICE_GUARD(cov2d);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = int((img_width + block_width - 1) / block_width);
    tile_bounds_dim3.y = int((img_height + block_width - 1) / block_width);
    tile_bounds_dim3.z = 1;

    torch::Tensor xys_d =
        torch::zeros({num_points, 2}, cov2d.options().dtype(torch::kFloat32));

    torch::Tensor extents_d =
        torch::zeros({num_points, 2}, cov2d.options().dtype(torch::kFloat32));
    torch::Tensor conics_d =
        torch::zeros({num_points, 3}, cov2d.options().dtype(torch::kFloat32));
    torch::Tensor num_tiles_hit_d =
        torch::zeros({num_points}, cov2d.options().dtype(torch::kInt32));

    project_gaussians_forward_kernel<<<
        (num_points + N_THREADS - 1) / N_THREADS,
        N_THREADS>>>(
        num_points,
        (float3 *)cov2d.contiguous().data_ptr<float>(),
        (float2 *)means2d.contiguous().data_ptr<float>(),
        opacities.has_value() ? opacities.value().contiguous().data_ptr<float>() : nullptr,
        tile_bounds_dim3,
        block_width,
        (float2 *)xys_d.contiguous().data_ptr<float>(),
        (float2 *)extents_d.contiguous().data_ptr<float>(),
        (float3 *)conics_d.contiguous().data_ptr<float>(),
        num_tiles_hit_d.contiguous().data_ptr<int32_t>()
    );

    return std::make_tuple(
            xys_d, extents_d, conics_d, num_tiles_hit_d
    );
}

std::tuple<
    torch::Tensor,
    torch::Tensor>
project_gaussians_backward_tensor(
    const int num_points,
    torch::Tensor &extent,
    torch::Tensor &conics,
    torch::Tensor &v_xy,
    torch::Tensor &v_conic
){
    DEVICE_GUARD(conics);
    // Triangular covariance.
    torch::Tensor v_cov2d =
        torch::zeros({num_points, 3}, conics.options().dtype(torch::kFloat32));

    torch::Tensor v_mean2d =
        torch::zeros({num_points, 2}, conics.options().dtype(torch::kFloat32));

    project_gaussians_backward_kernel<<<
        (num_points + N_THREADS - 1) / N_THREADS,
        N_THREADS>>>(
        num_points,
        (float2 *)extent.contiguous().data_ptr<float>(),
        (float3 *)conics.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float3 *)v_conic.contiguous().data_ptr<float>(),
        // Outputs.
        (float3 *)v_cov2d.contiguous().data_ptr<float>(),
        (float2 *)v_mean2d.contiguous().data_ptr<float>()
    );

    return std::make_tuple(v_cov2d, v_mean2d);
}

std::tuple<torch::Tensor, torch::Tensor> map_gaussian_to_intersects_tensor(
    const int num_points,
    const int num_intersects,
    const torch::Tensor &xys,
    const torch::Tensor &depths,
    const torch::Tensor &extent,
    const torch::Tensor &cum_tiles_hit,
    const std::tuple<int, int, int> tile_bounds,
    const unsigned block_width
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(depths);
    CHECK_INPUT(extent);
    CHECK_INPUT(cum_tiles_hit);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    torch::Tensor gaussian_ids_unsorted =
        torch::zeros({num_intersects}, xys.options().dtype(torch::kInt32));
    torch::Tensor isect_ids_unsorted =
        torch::zeros({num_intersects}, xys.options().dtype(torch::kInt64));

    map_gaussian_to_intersects<<<
        (num_points + N_THREADS - 1) / N_THREADS,
        N_THREADS>>>(
        num_points,
        (float2 *)xys.contiguous().data_ptr<float>(),
        depths.contiguous().data_ptr<float>(),
        (float2 *)extent.contiguous().data_ptr<float>(),
        cum_tiles_hit.contiguous().data_ptr<int32_t>(),
        tile_bounds_dim3,
        block_width,
        // Outputs.
        isect_ids_unsorted.contiguous().data_ptr<int64_t>(),
        gaussian_ids_unsorted.contiguous().data_ptr<int32_t>()
    );

    return std::make_tuple(isect_ids_unsorted, gaussian_ids_unsorted);
}

torch::Tensor get_tile_bin_edges_tensor(
    int num_intersects, const torch::Tensor &isect_ids_sorted, 
    const std::tuple<int, int, int> tile_bounds
) {
    DEVICE_GUARD(isect_ids_sorted);
    CHECK_INPUT(isect_ids_sorted);
    int num_tiles = std::get<0>(tile_bounds) * std::get<1>(tile_bounds);
    torch::Tensor tile_bins = torch::zeros(
        {num_tiles, 2}, isect_ids_sorted.options().dtype(torch::kInt32)
    );
    get_tile_bin_edges<<<
        (num_intersects + N_THREADS - 1) / N_THREADS,
        N_THREADS>>>(
        num_intersects,
        isect_ids_sorted.contiguous().data_ptr<int64_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>()
    );
    return tile_bins;
}

std::tuple<torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor>
rasterize_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &conics,
    const torch::Tensor &colors,
    const c10::optional<torch::Tensor> &opacities,
    bool compute_upscale_gradients
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(conics);
    CHECK_INPUT(colors);
    if (opacities.has_value()) {
        CHECK_INPUT(opacities.value());
    }

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );
    torch::Tensor out_wsum = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kFloat32)
    );
    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    torch::Tensor out_dx, out_dy, out_dxy;

    rasterize_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float3 *)conics.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        opacities.has_value() ? opacities.value().contiguous().data_ptr<float>() : nullptr,
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>(),
        out_wsum.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, out_wsum, out_dx, out_dy, out_dxy, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dxy_abs
        torch::Tensor, // dL_dconic
        torch::Tensor, // dL_dcolors
        torch::Tensor  // dL_dopacities
        >
    rasterize_backward_tensor(
        const unsigned img_height,
        const unsigned img_width,
        const unsigned block_width,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &conics,
        const torch::Tensor &colors,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output,
        const torch::Tensor &v_render_wsum,
        const c10::optional<torch::Tensor> &opacities,
        const c10::optional<torch::Tensor> &v_output_dx,
        const c10::optional<torch::Tensor> &v_output_dy,
        const c10::optional<torch::Tensor> &v_output_dxy
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);
    if (opacities.has_value()) {
        CHECK_INPUT(opacities.value());
    }

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (colors.ndimension() != 2 || colors.size(1) != 3) {
        AT_ERROR("colors must have 2 dimensions");
    }

    const int num_points = xys.size(0);
    const dim3 tile_bounds = {
        (img_width + block_width - 1) / block_width,
        (img_height + block_width - 1) / block_width,
        1
    };
    const dim3 block(block_width, block_width, 1);
    const dim3 img_size = {img_width, img_height, 1};
    const int channels = colors.size(1);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_xy_abs = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_conic = torch::zeros({num_points, 3}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());
    torch::Tensor v_opacity = opacities.has_value() 
        ? torch::zeros({num_points}, xys.options())
        : torch::Tensor();

    rasterize_backward_kernel<<<tile_bounds, block>>>(
        tile_bounds,
        img_size,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float3 *)conics.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        opacities.has_value() ? opacities.value().contiguous().data_ptr<float>() : nullptr,
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)v_output.contiguous().data_ptr<float>(),
        v_render_wsum.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_xy_abs.contiguous().data_ptr<float>(),
        (float3 *)v_conic.contiguous().data_ptr<float>(),
        (float3 *)v_colors.contiguous().data_ptr<float>(),
        opacities.has_value() ? v_opacity.contiguous().data_ptr<float>() : nullptr
    );

    return std::make_tuple(v_xy, v_xy_abs, v_conic, v_colors, v_opacity);
}



std::tuple<torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor>
rasterize_sigmoid_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &conics,
    const torch::Tensor &colors,
    const c10::optional<torch::Tensor> &opacities,
    bool compute_upscale_gradients
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(conics);
    CHECK_INPUT(colors);
    if (opacities.has_value()) {
        CHECK_INPUT(opacities.value());
    }

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );
    torch::Tensor out_wsum = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kFloat32)
    );
    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    torch::Tensor out_dx, out_dy, out_dxy;

    rasterize_sigmoid_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float3 *)conics.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        opacities.has_value() ? opacities.value().contiguous().data_ptr<float>() : nullptr,
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>(),
        out_wsum.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, out_wsum, out_dx, out_dy, out_dxy, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dxy_abs
        torch::Tensor, // dL_dconic
        torch::Tensor, // dL_dcolors
        torch::Tensor  // dL_dopacities
        >
    rasterize_sigmoid_backward_tensor(
        const unsigned img_height,
        const unsigned img_width,
        const unsigned block_width,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &conics,
        const torch::Tensor &colors,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output,
        const torch::Tensor &v_render_wsum,
        const c10::optional<torch::Tensor> &opacities,
        const c10::optional<torch::Tensor> &v_output_dx,
        const c10::optional<torch::Tensor> &v_output_dy,
        const c10::optional<torch::Tensor> &v_output_dxy
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);
    if (opacities.has_value()) {
        CHECK_INPUT(opacities.value());
    }

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (colors.ndimension() != 2 || colors.size(1) != 3) {
        AT_ERROR("colors must have 2 dimensions");
    }

    const int num_points = xys.size(0);
    const dim3 tile_bounds = {
        (img_width + block_width - 1) / block_width,
        (img_height + block_width - 1) / block_width,
        1
    };
    const dim3 block(block_width, block_width, 1);
    const dim3 img_size = {img_width, img_height, 1};
    const int channels = colors.size(1);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_xy_abs = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_conic = torch::zeros({num_points, 3}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());
    torch::Tensor v_opacity = opacities.has_value()
        ? torch::zeros({num_points}, xys.options())
        : torch::Tensor();

    rasterize_sigmoid_backward_kernel<<<tile_bounds, block>>>(
        tile_bounds,
        img_size,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float3 *)conics.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        opacities.has_value() ? opacities.value().contiguous().data_ptr<float>() : nullptr,
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)v_output.contiguous().data_ptr<float>(),
        v_render_wsum.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_xy_abs.contiguous().data_ptr<float>(),
        (float3 *)v_conic.contiguous().data_ptr<float>(),
        (float3 *)v_colors.contiguous().data_ptr<float>(),
        opacities.has_value() ? v_opacity.contiguous().data_ptr<float>() : nullptr
    );

    return std::make_tuple(v_xy, v_xy_abs, v_conic, v_colors, v_opacity);
}



std::tuple<torch::Tensor, torch::Tensor>
rasterize_uv_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &log_scales,  // log(sx), log(sy)
    const torch::Tensor &thetas,  // radians
    const torch::Tensor &colors
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(log_scales);
    CHECK_INPUT(thetas);
    CHECK_INPUT(colors);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );

    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    rasterize_uv_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dlog_scales
        torch::Tensor, // dL_dthetas
        torch::Tensor // dL_dcolors
        >
    rasterize_uv_backward_tensor(
        const unsigned img_height,
        const unsigned img_width,
        const unsigned block_width,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &log_scales,
        const torch::Tensor &thetas,
        const torch::Tensor &colors,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (log_scales.ndimension() != 2 || log_scales.size(1) != 2) {
        AT_ERROR("log_scales must have dimensions (num_points, 2)");
    }

    if (thetas.ndimension() != 2 || thetas.size(1) != 1) {
        AT_ERROR("thetas must have dimensions (num_points, 1)");
//         AT_ERROR(
//             "thetas must have dimensions (num_points, 1)\n"
//             "Actual thetas dimensions: ", thetas.sizes(), "\n"
//             "Actual xys.size(1): ", xys.size(1)
//         );
    }

    if (colors.ndimension() != 2 || colors.size(1) != 3) {
        AT_ERROR("colors must have 3 dimensions");
    }

    const int num_points = xys.size(0);
    const dim3 tile_bounds = {
        (img_width + block_width - 1) / block_width,
        (img_height + block_width - 1) / block_width,
        1
    };
    const dim3 block(block_width, block_width, 1);
    const dim3 img_size = {img_width, img_height, 1};
    const int channels = colors.size(1);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_log_scales = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_thetas = torch::zeros({num_points, 1}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());

    rasterize_uv_backward_kernel<<<tile_bounds, block>>>(
        tile_bounds,
        img_size,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)v_output.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_log_scales.contiguous().data_ptr<float>(),
        (float *)v_thetas.contiguous().data_ptr<float>(),
        (float3 *)v_colors.contiguous().data_ptr<float>()
    );

    return std::make_tuple(v_xy, v_log_scales, v_thetas, v_colors);
}



std::tuple<torch::Tensor, torch::Tensor>
rasterize_uv_sigmoid_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &log_scales,  // log(sx), log(sy)
    const torch::Tensor &thetas,  // radians
    const torch::Tensor &colors
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(log_scales);
    CHECK_INPUT(thetas);
    CHECK_INPUT(colors);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );

    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    rasterize_uv_sigmoid_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dlog_scales
        torch::Tensor, // dL_dthetas
        torch::Tensor // dL_dcolors
        >
    rasterize_uv_sigmoid_backward_tensor(
        const unsigned img_height,
        const unsigned img_width,
        const unsigned block_width,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &log_scales,
        const torch::Tensor &thetas,
        const torch::Tensor &colors,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (log_scales.ndimension() != 2 || log_scales.size(1) != 2) {
        AT_ERROR("log_scales must have dimensions (num_points, 2)");
    }

    if (thetas.ndimension() != 2 || thetas.size(1) != 1) {
        AT_ERROR("thetas must have dimensions (num_points, 1)");
//         AT_ERROR(
//             "thetas must have dimensions (num_points, 1)\n"
//             "Actual thetas dimensions: ", thetas.sizes(), "\n"
//             "Actual xys.size(1): ", xys.size(1)
//         );
    }

    if (colors.ndimension() != 2 || colors.size(1) != 3) {
        AT_ERROR("colors must have 3 dimensions");
    }

    const int num_points = xys.size(0);
    const dim3 tile_bounds = {
        (img_width + block_width - 1) / block_width,
        (img_height + block_width - 1) / block_width,
        1
    };
    const dim3 block(block_width, block_width, 1);
    const dim3 img_size = {img_width, img_height, 1};
    const int channels = colors.size(1);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_log_scales = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_thetas = torch::zeros({num_points, 1}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());

    rasterize_uv_sigmoid_backward_kernel<<<tile_bounds, block>>>(
        tile_bounds,
        img_size,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)v_output.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_log_scales.contiguous().data_ptr<float>(),
        (float *)v_thetas.contiguous().data_ptr<float>(),
        (float3 *)v_colors.contiguous().data_ptr<float>()
    );

    return std::make_tuple(v_xy, v_log_scales, v_thetas, v_colors);
}


std::tuple<torch::Tensor, torch::Tensor>
rasterize_uv_sigmoid_k_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &log_scales,  // log(sx), log(sy)
    const torch::Tensor &thetas,  // radians
    const torch::Tensor &sig_k,
    const torch::Tensor &colors
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(log_scales);
    CHECK_INPUT(thetas);
    CHECK_INPUT(sig_k);
    CHECK_INPUT(colors);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );

    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    rasterize_uv_sigmoid_k_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dlog_scales
        torch::Tensor, // dL_dthetas
        torch::Tensor, // dL_dsig_k
        torch::Tensor // dL_dcolors
        >
    rasterize_uv_sigmoid_k_backward_tensor(
        const unsigned img_height,
        const unsigned img_width,
        const unsigned block_width,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &log_scales,
        const torch::Tensor &thetas,
        const torch::Tensor &sig_k,
        const torch::Tensor &colors,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (log_scales.ndimension() != 2 || log_scales.size(1) != 2) {
        AT_ERROR("log_scales must have dimensions (num_points, 2)");
    }

    if (thetas.ndimension() != 2 || thetas.size(1) != 1) {
        AT_ERROR("thetas must have dimensions (num_points, 1)");
    }

    if (sig_k.ndimension() != 2 || sig_k.size(1) != 2) {
        AT_ERROR("sig_k must have dimensions (num_points, 2)");
    }

    if (colors.ndimension() != 2 || colors.size(1) != 3) {
        AT_ERROR("colors must have 3 dimensions");
    }

    const int num_points = xys.size(0);
    const dim3 tile_bounds = {
        (img_width + block_width - 1) / block_width,
        (img_height + block_width - 1) / block_width,
        1
    };
    const dim3 block(block_width, block_width, 1);
    const dim3 img_size = {img_width, img_height, 1};
    const int channels = colors.size(1);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_log_scales = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_thetas = torch::zeros({num_points, 1}, xys.options());
    torch::Tensor v_sig_k = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());

    rasterize_uv_sigmoid_k_backward_kernel<<<tile_bounds, block>>>(
        tile_bounds,
        img_size,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)v_output.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_log_scales.contiguous().data_ptr<float>(),
        (float *)v_thetas.contiguous().data_ptr<float>(),
        (float2 *)v_sig_k.contiguous().data_ptr<float>(),
        (float3 *)v_colors.contiguous().data_ptr<float>()
    );

    return std::make_tuple(v_xy, v_log_scales, v_thetas, v_sig_k, v_colors);
}


std::tuple<torch::Tensor, torch::Tensor>
rasterize_position_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &log_scales,  // log(sx), log(sy)
    const torch::Tensor &thetas,  // radians
    const torch::Tensor &sig_k,
    const torch::Tensor &colors,
    const torch::Tensor &pxs,
    const torch::Tensor &pys
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(log_scales);
    CHECK_INPUT(thetas);
    CHECK_INPUT(sig_k);
    CHECK_INPUT(colors);


    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    const int channels = colors.size(1);
    const int pix_num = pxs.size(0);

    torch::Tensor out_img = torch::zeros({pix_num, channels}, xys.options().dtype(torch::kFloat32));
    torch::Tensor final_idx = torch::zeros({pix_num}, xys.options().dtype(torch::kInt32));

    int blocks = (pix_num + N_THREADS - 1) / N_THREADS;

    rasterize_position_forward<<<blocks, N_THREADS>>>(
        pix_num,
        tile_bounds_dim3,
        block_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        (float *)pxs.contiguous().data_ptr<float>(),
        (float *)pys.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dlog_scales
        torch::Tensor, // dL_dthetas
        torch::Tensor, // dL_dsig_k
        torch::Tensor // dL_dcolors
        >
    rasterize_position_backward_tensor(
        const std::tuple<int, int, int> tile_bounds,
        const std::tuple<int, int, int> block,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &log_scales,
        const torch::Tensor &thetas,
        const torch::Tensor &sig_k,
        const torch::Tensor &colors,
        const torch::Tensor &pxs,
        const torch::Tensor &pys,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (log_scales.ndimension() != 2 || log_scales.size(1) != 2) {
        AT_ERROR("log_scales must have dimensions (num_points, 2)");
    }

    if (thetas.ndimension() != 2 || thetas.size(1) != 1) {
        AT_ERROR("thetas must have dimensions (num_points, 1)");
    }

    if (sig_k.ndimension() != 2 || sig_k.size(1) != 2) {
        AT_ERROR("sig_k must have dimensions (num_points, 2)");
    }

    if (colors.ndimension() != 2 || colors.size(1) != 3) {
        AT_ERROR("colors must have 3 dimensions");
    }

    const int num_points = xys.size(0);
    const int channels = colors.size(1);
    const int pix_num = pxs.size(0);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_log_scales = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_thetas = torch::zeros({num_points, 1}, xys.options());
    torch::Tensor v_sig_k = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    int blocks = (pix_num + N_THREADS - 1) / N_THREADS;
    rasterize_position_backward_kernel<<<blocks, N_THREADS>>>(
        pix_num,
        tile_bounds_dim3,
        block_dim3,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        (float *)pxs.contiguous().data_ptr<float>(),
        (float *)pys.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)v_output.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_log_scales.contiguous().data_ptr<float>(),
        (float *)v_thetas.contiguous().data_ptr<float>(),
        (float2 *)v_sig_k.contiguous().data_ptr<float>(),
        (float3 *)v_colors.contiguous().data_ptr<float>()
    );

    return std::make_tuple(v_xy, v_log_scales, v_thetas, v_sig_k, v_colors);
}



std::tuple<torch::Tensor, torch::Tensor>
rasterize_uv_sigmoid_k_randpos_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &log_scales,  // log(sx), log(sy)
    const torch::Tensor &thetas,  // radians
    const torch::Tensor &sig_k,
    const torch::Tensor &colors,
    const torch::Tensor &randpos
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(log_scales);
    CHECK_INPUT(thetas);
    CHECK_INPUT(sig_k);
    CHECK_INPUT(colors);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );

    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    rasterize_uv_sigmoid_k_randpos_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float3 *)colors.contiguous().data_ptr<float>(),
        (float2 *)randpos.contiguous().data_ptr<float>(),
        final_idx.contiguous().data_ptr<int>(),
        (float3 *)out_img.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, final_idx);
}


std::tuple<torch::Tensor, torch::Tensor>
rasterize_uv_sigmoid_k_beta_forward_tensor(
    const std::tuple<int, int, int> tile_bounds,
    const std::tuple<int, int, int> block,
    const std::tuple<int, int, int> img_size,
    const torch::Tensor &gaussian_ids_sorted,
    const torch::Tensor &tile_bins,
    const torch::Tensor &xys,
    const torch::Tensor &log_scales,  // log(sx), log(sy)
    const torch::Tensor &thetas,  // radians
    const torch::Tensor &sig_k,
    const torch::Tensor &betas,
    const torch::Tensor &colors
) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(gaussian_ids_sorted);
    CHECK_INPUT(tile_bins);
    CHECK_INPUT(xys);
    CHECK_INPUT(log_scales);
    CHECK_INPUT(thetas);
    CHECK_INPUT(sig_k);
    CHECK_INPUT(betas);
    CHECK_INPUT(colors);

    dim3 tile_bounds_dim3;
    tile_bounds_dim3.x = std::get<0>(tile_bounds);
    tile_bounds_dim3.y = std::get<1>(tile_bounds);
    tile_bounds_dim3.z = std::get<2>(tile_bounds);

    dim3 block_dim3;
    block_dim3.x = std::get<0>(block);
    block_dim3.y = std::get<1>(block);
    block_dim3.z = std::get<2>(block);

    dim3 img_size_dim3;
    img_size_dim3.x = std::get<0>(img_size);
    img_size_dim3.y = std::get<1>(img_size);
    img_size_dim3.z = std::get<2>(img_size);

    const int channels = colors.size(1);
    const int img_width = img_size_dim3.x;
    const int img_height = img_size_dim3.y;

    torch::Tensor out_img = torch::zeros(
        {img_height, img_width, channels}, xys.options().dtype(torch::kFloat32)
    );

    torch::Tensor final_idx = torch::zeros(
        {img_height, img_width}, xys.options().dtype(torch::kInt32)
    );

    rasterize_uv_sigmoid_k_beta_forward<<<tile_bounds_dim3, block_dim3>>>(
        tile_bounds_dim3,
        img_size_dim3,
        gaussian_ids_sorted.contiguous().data_ptr<int32_t>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float *)betas.contiguous().data_ptr<float>(),
        (float *)colors.contiguous().data_ptr<float>(),
        channels,
        final_idx.contiguous().data_ptr<int>(),
        (float *)out_img.contiguous().data_ptr<float>()
    );

    return std::make_tuple(out_img, final_idx);
}

std::
    tuple<
        torch::Tensor, // dL_dxy
        torch::Tensor, // dL_dlog_scales
        torch::Tensor, // dL_dthetas
        torch::Tensor, // dL_dsig_k
        torch::Tensor, // dL_dbeta
        torch::Tensor // dL_dcolors
        >
    rasterize_uv_sigmoid_k_beta_backward_tensor(
        const unsigned img_height,
        const unsigned img_width,
        const unsigned block_width,
        const torch::Tensor &gaussians_ids_sorted,
        const torch::Tensor &tile_bins,
        const torch::Tensor &xys,
        const torch::Tensor &log_scales,
        const torch::Tensor &thetas,
        const torch::Tensor &sig_k,
        const torch::Tensor &betas,
        const torch::Tensor &colors,
        const torch::Tensor &final_idx,
        const torch::Tensor &v_output
    ) {
    DEVICE_GUARD(xys);
    CHECK_INPUT(xys);
    CHECK_INPUT(colors);

    if (xys.ndimension() != 2 || xys.size(1) != 2) {
        AT_ERROR("xys must have dimensions (num_points, 2)");
    }

    if (log_scales.ndimension() != 2 || log_scales.size(1) != 2) {
        AT_ERROR("log_scales must have dimensions (num_points, 2)");
    }

    if (thetas.ndimension() != 2 || thetas.size(1) != 1) {
        AT_ERROR("thetas must have dimensions (num_points, 1)");
    }

    if (sig_k.ndimension() != 2 || sig_k.size(1) != 2) {
        AT_ERROR("sig_k must have dimensions (num_points, 2)");
    }

    const int num_points = xys.size(0);
    const dim3 tile_bounds = {
        (img_width + block_width - 1) / block_width,
        (img_height + block_width - 1) / block_width,
        1
    };
    const dim3 block(block_width, block_width, 1);
    const dim3 img_size = {img_width, img_height, 1};
    const int channels = colors.size(1);

    torch::Tensor v_xy = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_log_scales = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_thetas = torch::zeros({num_points, 1}, xys.options());
    torch::Tensor v_sig_k = torch::zeros({num_points, 2}, xys.options());
    torch::Tensor v_betas = torch::zeros({num_points, 1}, xys.options());
    torch::Tensor v_colors =
        torch::zeros({num_points, channels}, xys.options());

    rasterize_uv_sigmoid_k_beta_backward_kernel<<<tile_bounds, block>>>(
        tile_bounds,
        img_size,
        gaussians_ids_sorted.contiguous().data_ptr<int>(),
        (int2 *)tile_bins.contiguous().data_ptr<int>(),
        (float2 *)xys.contiguous().data_ptr<float>(),
        (float2 *)log_scales.contiguous().data_ptr<float>(),
        (float *)thetas.contiguous().data_ptr<float>(),
        (float2 *)sig_k.contiguous().data_ptr<float>(),
        (float *)betas.contiguous().data_ptr<float>(),
        (float *)colors.contiguous().data_ptr<float>(),
        channels,
        final_idx.contiguous().data_ptr<int>(),
        (float *)v_output.contiguous().data_ptr<float>(),
        (float2 *)v_xy.contiguous().data_ptr<float>(),
        (float2 *)v_log_scales.contiguous().data_ptr<float>(),
        (float *)v_thetas.contiguous().data_ptr<float>(),
        (float2 *)v_sig_k.contiguous().data_ptr<float>(),
        (float *)v_betas.contiguous().data_ptr<float>(),
        (float *)v_colors.contiguous().data_ptr<float>()
    );

    return std::make_tuple(v_xy, v_log_scales, v_thetas, v_sig_k, v_betas, v_colors);
}
