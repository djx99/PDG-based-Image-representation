#include "forward.cuh"
#include "helpers.cuh"
#include <algorithm>
#include <cooperative_groups.h>
#include <cooperative_groups/reduce.h>
#include <iostream>
#include <cuda_fp16.h>

namespace cg = cooperative_groups;

// kernel function for projecting each gaussian on device
// each thread processes one gaussian
__global__ void project_gaussians_forward_kernel(
    const int num_points,    
    const float3* __restrict__ cov2d,
    const float2* __restrict__ means2d,
    const float* __restrict__ opacities,
    const dim3 tile_bounds,
    const unsigned block_width,
    float2* __restrict__ xys,
    float2* __restrict__ extents,
    float3* __restrict__ conics,
    int32_t* __restrict__ num_tiles_hit
) {
    unsigned idx = cg::this_grid().thread_rank(); // idx of thread within grid
    if (idx >= num_points) {
        return;
    }
    extents[idx] = {0.f, 0.f};
    num_tiles_hit[idx] = 0;

    float3 conic;
    float2 extent;
    float3 cov2d_f = cov2d[idx];
    float opacity = opacities ? opacities[idx] : 1.0f;
    bool ok = compute_cov2d_bounds(cov2d_f, opacity, conic, extent);
    if (!ok)
        return; // zero determinant

    conics[idx] = conic;

    float2 center = means2d[idx];
    uint2 tile_min, tile_max;
    get_tile_bbox(center, extent, tile_bounds, tile_min, tile_max, block_width);
    int32_t tile_area = (tile_max.x - tile_min.x) * (tile_max.y - tile_min.y);
    if (tile_area <= 0) {
        return;
    }

    num_tiles_hit[idx] = tile_area;
    extents[idx] = extent;
    xys[idx] = center;
}


// kernel to map each intersection from tile ID and depth to a gaussian
// writes output to isect_ids and gaussian_ids
__global__ void map_gaussian_to_intersects(
    const int num_points,
    const float2* __restrict__ xys,
    const float* __restrict__ depths,
    const float2* __restrict__ extent,
    const int32_t* __restrict__ cum_tiles_hit,
    const dim3 tile_bounds,
    const unsigned block_width,
    int64_t* __restrict__ isect_ids,
    int32_t* __restrict__ gaussian_ids
) {
    unsigned idx = cg::this_grid().thread_rank();
    if (idx >= num_points)
        return;
    if (extent[idx].x <= 0.f || extent[idx].y <= 0.f)
        return;
    // get the tile bbox for gaussian
    uint2 tile_min, tile_max;
    float2 center = xys[idx];
    get_tile_bbox(center, extent[idx], tile_bounds, tile_min, tile_max, block_width);

    // update the intersection info for all tiles this gaussian hits
    int32_t cur_idx = (idx == 0) ? 0 : cum_tiles_hit[idx - 1];
    // printf("point %d starting at %d\n", idx, cur_idx);
    int64_t depth_id = (int64_t) * (int32_t *)&(depths[idx]);
    for (int i = tile_min.y; i < tile_max.y; ++i) {
        for (int j = tile_min.x; j < tile_max.x; ++j) {
            // isect_id is tile ID and depth as int32
            int64_t tile_id = i * tile_bounds.x + j; // tile within image
            isect_ids[cur_idx] = (tile_id << 32) | depth_id; // tile | depth id
            gaussian_ids[cur_idx] = idx;                     // 3D gaussian id
            ++cur_idx; // handles gaussians that hit more than one tile
        }
    }
}

// kernel to map sorted intersection IDs to tile bins
// expect that intersection IDs are sorted by increasing tile ID
// i.e. intersections of a tile are in contiguous chunks
__global__ void get_tile_bin_edges(
    const int num_intersects, const int64_t* __restrict__ isect_ids_sorted, int2* __restrict__ tile_bins
) {
    unsigned idx = cg::this_grid().thread_rank();
    if (idx >= num_intersects)
        return;
    // save the indices where the tile_id changes
    int32_t cur_tile_idx = (int32_t)(isect_ids_sorted[idx] >> 32);
    if (idx == 0 || idx == num_intersects - 1) {
        if (idx == 0)
            tile_bins[cur_tile_idx].x = 0;
        if (idx == num_intersects - 1)
            tile_bins[cur_tile_idx].y = num_intersects;
    }
    if (idx == 0)
        return;
    int32_t prev_tile_idx = (int32_t)(isect_ids_sorted[idx - 1] >> 32);
    if (prev_tile_idx != cur_tile_idx) {
        tile_bins[prev_tile_idx].y = idx;
        tile_bins[cur_tile_idx].x = idx;
        return;
    }
}


__global__ void rasterize_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float3* __restrict__ conics,
    const float3* __restrict__ colors,
    const float* __restrict__ opacities,
    int* __restrict__ final_index,
    float3* __restrict__ out_img,
    float* __restrict__ out_wsum
) {

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    float px = (float)j + 0.5;
    float py = (float)i + 0.5;
    int32_t pix_id = i * img_size.x + j;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    // __shared__ float3 xy_opacity_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float3 conic_batch[MAX_BLOCK_SIZE];
    __shared__ float opacity_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
    float3 pix_out = {0.f, 0.f, 0.f};
    float pix_wsum = 0.f;
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            conic_batch[tr] = conics[g_id];
            opacity_batch[tr] = opacities ? opacities[g_id] : 1.0f;
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float3 conic = conic_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};
            const float sigma = 0.5f * (conic.x * delta.x * delta.x +
                                        conic.z * delta.y * delta.y) +
                                conic.y * delta.x * delta.y;
            const float opacity = opacity_batch[t];
            const float alpha = min(0.999f, opacity * __expf(-sigma));
            if (sigma < 0.f || alpha < 1.f / 255.f) {
                continue;
            }

            int32_t g = id_batch[t];
            const float3 c = colors[g];
            pix_out += c * alpha;
            // Accumulate weighted sum of alphas
            pix_wsum += alpha;
            
            cur_idx = batch_start + t;
        }
    }

    if (inside) {
        final_index[pix_id] =
            cur_idx; // index of in bin of last gaussian in this pixel
        out_img[pix_id] = pix_out;
        out_wsum[pix_id] = pix_wsum;
    }
}



__global__ void rasterize_sigmoid_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float3* __restrict__ conics,
    const float3* __restrict__ colors,
    const float* __restrict__ opacities,
    int* __restrict__ final_index,
    float3* __restrict__ out_img,
    float* __restrict__ out_wsum
) {

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    float px = (float)j + 0.5;
    float py = (float)i + 0.5;
    int32_t pix_id = i * img_size.x + j;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    // __shared__ float3 xy_opacity_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float3 conic_batch[MAX_BLOCK_SIZE];
    __shared__ float opacity_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
    float3 pix_out = {0.f, 0.f, 0.f};
    float pix_wsum = 0.f;
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            conic_batch[tr] = conics[g_id];
            opacity_batch[tr] = opacities ? opacities[g_id] : 1.0f;
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float3 conic = conic_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};
            const float sigma = 0.5f * (conic.x * delta.x * delta.x +
                                        conic.z * delta.y * delta.y) +
                                conic.y * delta.x * delta.y;
            const float opacity = opacity_batch[t];

            const float gate = sigmoid_k((float)SIGMOID_K,  delta.x) * sigmoid_k((float)SIGMOID_K,  delta.y);

            //const float alpha = min(0.999f, opacity * __expf(-sigma) * gate);
            const float alpha = opacity * __expf(-sigma) * gate;
            if (sigma < 0.f || alpha < 1.f / 255.f) {
                continue;
            }

            int32_t g = id_batch[t];
            const float3 c = colors[g];
            pix_out += c * alpha;
            // Accumulate weighted sum of alphas
            pix_wsum += alpha;

            cur_idx = batch_start + t;
        }
    }

    if (inside) {
        final_index[pix_id] =
            cur_idx; // index of in bin of last gaussian in this pixel
        out_img[pix_id] = pix_out;
        out_wsum[pix_id] = pix_wsum;
    }
}


// compute output color image from binned and sorted gaussians
__global__ void rasterize_uv_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float3* __restrict__ colors,
    int* __restrict__ final_index,
    float3* __restrict__ out_img
){

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    float px = (float)j + 0.5;
    float py = (float)i + 0.5;
    int32_t pix_id = i * img_size.x + j;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
    float3 pix_out = {0.f, 0.f, 0.f};
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float2 log_scale = log_scales_batch[t];
            const float theta = thetas_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};

            const float inv_sx = __expf(-log_scale.x);
            const float inv_sy = __expf(-log_scale.y);
            float ssin, ccos;
            __sincosf(theta, &ssin, &ccos);

            const float uu = (ccos * delta.x + ssin * delta.y);
            const float vv = (-ssin * delta.x + ccos * delta.y);

            const float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);
            const float alpha = __expf(-sigma);
            if (sigma < 0.f || alpha < 1.f / 255.f) {
                continue;
            }

            int32_t g = id_batch[t];
            const float3 c = colors[g];
            pix_out += c * alpha;

            cur_idx = batch_start + t;
        }
    }

    if (inside) {
        final_index[pix_id] =
            cur_idx; // index of in bin of last gaussian in this pixel
        out_img[pix_id] = pix_out;
    }
}

// compute output color image from binned and sorted gaussians
__global__ void rasterize_uv_sigmoid_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float3* __restrict__ colors,
    int* __restrict__ final_index,
    float3* __restrict__ out_img
){

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    float px = (float)j + 0.5;
    float py = (float)i + 0.5;
    int32_t pix_id = i * img_size.x + j;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
    float3 pix_out = {0.f, 0.f, 0.f};
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float2 log_scale = log_scales_batch[t];
            const float theta = thetas_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};

            const float inv_sx = __expf(-log_scale.x);
            const float inv_sy = __expf(-log_scale.y);
            float ssin, ccos;
            __sincosf(theta, &ssin, &ccos);

            const float uu = (ccos * delta.x + ssin * delta.y);
            const float vv = (-ssin * delta.x + ccos * delta.y);

            const float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);
            const float gate = sigmoid_k((float)SIGMOID_K,  uu) * sigmoid_k((float)SIGMOID_K,  vv);

            const float alpha = __expf(-sigma) * gate;
            if (sigma < 0.f || alpha < 1.f / 255.f) {
                continue;
            }

            int32_t g = id_batch[t];
            const float3 c = colors[g];
            pix_out += c * alpha;

            cur_idx = batch_start + t;
        }
    }

    if (inside) {
        final_index[pix_id] =
            cur_idx; // index of in bin of last gaussian in this pixel
        out_img[pix_id] = pix_out;
    }
}


// compute output color image from binned and sorted gaussians
__global__ void rasterize_uv_sigmoid_k_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float3* __restrict__ colors,
    int* __restrict__ final_index,
    float3* __restrict__ out_img
){

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    float px = (float)j + 0.5;
    float py = (float)i + 0.5;
    int32_t pix_id = i * img_size.x + j;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float2 sig_k_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
    float3 pix_out = {0.f, 0.f, 0.f};
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
            sig_k_batch[tr] = sig_k[g_id];
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float2 log_scale = log_scales_batch[t];
            const float2 sig_k_one = sig_k_batch[t];
            const float theta = thetas_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};

            const float inv_sx = __expf(-log_scale.x);
            const float inv_sy = __expf(-log_scale.y);
            float ssin, ccos;
            __sincosf(theta, &ssin, &ccos);

            const float uu = (ccos * delta.x + ssin * delta.y);
            const float vv = (-ssin * delta.x + ccos * delta.y);

            const float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);
            const float gate = sigmoid_k(sig_k_one.x,  uu) * sigmoid_k(sig_k_one.y,  vv);

            const float alpha = __expf(-sigma) * gate;
            if (sigma < 0.f || alpha < 1.f / 255.f) {
                continue;
            }

            int32_t g = id_batch[t];
            const float3 c = colors[g];
            pix_out += c * alpha;

            cur_idx = batch_start + t;
        }
    }

    if (inside) {
        final_index[pix_id] =
            cur_idx; // index of in bin of last gaussian in this pixel
        out_img[pix_id] = pix_out;
    }
}


// compute output color image from binned and sorted gaussians
__global__ void rasterize_position_forward(
    const int pix_num,
    const dim3 tile_bounds,
    const dim3 tile_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float3* __restrict__ colors,
    const float* __restrict__ pxs,
    const float* __restrict__ pys,
    int* __restrict__ final_index,
    float3* __restrict__ out_img
){

    unsigned idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= pix_num)
        return;

    float px = pxs[idx];
    float py = pys[idx];
    int tile_x = (int)(px / (float)tile_size.x);
    int tile_y = (int)(py / (float)tile_size.y);
    if (tile_x < 0 || tile_x >= (int)tile_bounds.x || tile_y < 0 || tile_y >= (int)tile_bounds.y) {
        return;
    }
    int32_t tile_id = tile_y * (int)tile_bounds.x + tile_x;

    int2 range = tile_bins[tile_id];

    float3 pix_out = {0.f, 0.f, 0.f};
    int cur_idx = 0;

    // 直接遍历该 tile 的 gaussian（先跑通；之后再考虑 batching / shared）
    for (int p = range.x; p < range.y; ++p) {
        int32_t g_id = gaussian_ids_sorted[p];

        const float2 log_scale = log_scales[g_id];
        const float2 sig_k_one = sig_k[g_id];
        const float theta = thetas[g_id];
        const float2 xy = xys[g_id];
        const float2 delta = {xy.x - px, xy.y - py};

        const float inv_sx = __expf(-log_scale.x);
        const float inv_sy = __expf(-log_scale.y);
        float ssin, ccos;
        __sincosf(theta, &ssin, &ccos);

        const float uu = (ccos * delta.x + ssin * delta.y);
        const float vv = (-ssin * delta.x + ccos * delta.y);

        const float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);
        const float gate = sigmoid_k(sig_k_one.x, uu) * sigmoid_k(sig_k_one.y, vv);

        const float alpha = __expf(-sigma) * gate;

        const float3 c = colors[g_id];
        pix_out += c * alpha;
        cur_idx = p;
    }

    final_index[idx] = cur_idx;
    out_img[idx] = pix_out;
}




// compute output color image from binned and sorted gaussians
__global__ void rasterize_uv_sigmoid_k_randpos_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float3* __restrict__ colors,
    const float2* __restrict__ randpos,
    int* __restrict__ final_index,
    float3* __restrict__ out_img
){

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    int32_t pix_id = i * img_size.x + j;
    float px = (float)j + randpos[pix_id].x;
    float py = (float)i + randpos[pix_id].y;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float2 sig_k_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
    float3 pix_out = {0.f, 0.f, 0.f};
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
            sig_k_batch[tr] = sig_k[g_id];
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float2 log_scale = log_scales_batch[t];
            const float2 sig_k_one = sig_k_batch[t];
            const float theta = thetas_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};

            const float inv_sx = __expf(-log_scale.x);
            const float inv_sy = __expf(-log_scale.y);
            float ssin, ccos;
            __sincosf(theta, &ssin, &ccos);

            const float uu = (ccos * delta.x + ssin * delta.y);
            const float vv = (-ssin * delta.x + ccos * delta.y);

            const float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);
            const float gate = sigmoid_k(sig_k_one.x,  uu) * sigmoid_k(sig_k_one.y,  vv);

            const float alpha = __expf(-sigma) * gate;
//             if (sigma < 0.f || alpha < 1.f / 255.f) {
//                 continue;
//             }

            int32_t g = id_batch[t];
            const float3 c = colors[g];
            pix_out += c * alpha;

            cur_idx = batch_start + t;
        }
    }

    if (inside) {
        final_index[pix_id] =
            cur_idx; // index of in bin of last gaussian in this pixel
        out_img[pix_id] = pix_out;
    }
}


// compute output color image from binned and sorted gaussians
__global__ void rasterize_uv_sigmoid_k_beta_forward(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float* __restrict__ betas,
    const float* __restrict__ colors,
    int channels,
    int* __restrict__ final_index,
    float* __restrict__ out_img
){

    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    float px = (float)j + 0.5;
    float py = (float)i + 0.5;
    int32_t pix_id = i * img_size.x + j;

    // return if out of bounds
    // keep not rasterizing threads around for reading data
    bool inside = (i < img_size.y && j < img_size.x);
    bool done = !inside;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float2 sig_k_batch[MAX_BLOCK_SIZE];
    __shared__ float betas_batch[MAX_BLOCK_SIZE];

    int cur_idx = 0;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing its
    // designated pixel
    int tr = block.thread_rank();
//     float3 pix_out = {0.f, 0.f, 0.f};

    float pix_out[8];
    #pragma unroll
    for (int c = 0; c < 8; ++c) pix_out[c] = 0.f;

    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before beginning next batch
        // end early if entire tile is done
        if (__syncthreads_count(done) >= block_size) {
            break;
        }

        // each thread fetch 1 gaussian from front to back
        // index of gaussian to load
        int batch_start = range.x + block_size * b;
        int idx = batch_start + tr;
        if (idx < range.y) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
            sig_k_batch[tr] = sig_k[g_id];
            betas_batch[tr] = betas[g_id];
        }

        // wait for other threads to collect the gaussians in batch
        block.sync();

        // process gaussians in the current batch for this pixel
        int batch_size = min(block_size, range.y - batch_start);
        for (int t = 0; (t < batch_size) && !done; ++t) {
            const float2 log_scale = log_scales_batch[t];
            const float2 sig_k_one = sig_k_batch[t];
            const float theta = thetas_batch[t];
            const float beta = betas_batch[t];
            const float2 xy = xy_batch[t];
            const float2 delta = {xy.x - px, xy.y - py};

            const float inv_sx = __expf(-log_scale.x);
            const float inv_sy = __expf(-log_scale.y);
            float ssin, ccos;
            __sincosf(theta, &ssin, &ccos);

            constexpr float eps = 1e-6f;
            const float uu = (ccos * delta.x + ssin * delta.y);
            const float vv = (-ssin * delta.x + ccos * delta.y);
            const float sigma = uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy + eps;
            const float gate = sigmoid_k(sig_k_one.x,  uu) * sigmoid_k(sig_k_one.y,  vv);

            const float sigma_beta = __powf(sigma, beta);
            const float alpha = __expf(-0.5f * sigma_beta) * gate;

            if (sigma < 0.f || alpha < 1.f / 255.f) {
                continue;
            }

            int32_t g = id_batch[t];

//             const float3 c = colors[g];
//             pix_out += c * alpha;
            #pragma unroll 1
            for (int c = 0; c < channels; ++c) {
                pix_out[c] += colors[g * channels + c] * alpha;
            }

            cur_idx = batch_start + t;

        }
    }

    if (inside) {
        final_index[pix_id] = cur_idx; // index of in bin of last gaussian in this pixel
//         out_img[pix_id] = pix_out;
        #pragma unroll 1
        for (int c = 0; c < channels; ++c) {
            out_img[pix_id * channels + c] = pix_out[c];
        }
    }
}
