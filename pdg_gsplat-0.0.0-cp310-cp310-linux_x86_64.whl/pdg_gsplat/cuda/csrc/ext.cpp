#include "bindings.h"
#include <torch/extension.h>

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rasterize_forward", &rasterize_forward_tensor);
    m.def("rasterize_backward", &rasterize_backward_tensor);
    m.def("project_gaussians_forward", &project_gaussians_forward_tensor);
    m.def("project_gaussians_backward", &project_gaussians_backward_tensor);
    
    m.def("compute_cov2d_bounds", &compute_cov2d_bounds_tensor);
    m.def("map_gaussian_to_intersects", &map_gaussian_to_intersects_tensor);
    m.def("get_tile_bin_edges", &get_tile_bin_edges_tensor);

    m.def("rasterize_sigmoid_forward", &rasterize_sigmoid_forward_tensor);
    m.def("rasterize_sigmoid_backward", &rasterize_sigmoid_backward_tensor);

    m.def("rasterize_uv_forward", &rasterize_uv_forward_tensor);
    m.def("rasterize_uv_backward", &rasterize_uv_backward_tensor);

    m.def("rasterize_uv_sigmoid_forward", &rasterize_uv_sigmoid_forward_tensor);
    m.def("rasterize_uv_sigmoid_backward", &rasterize_uv_sigmoid_backward_tensor);

    m.def("rasterize_uv_sigmoid_k_forward", &rasterize_uv_sigmoid_k_forward_tensor);
    m.def("rasterize_uv_sigmoid_k_backward", &rasterize_uv_sigmoid_k_backward_tensor);

    m.def("rasterize_position_forward", &rasterize_position_forward_tensor);
    m.def("rasterize_position_backward", &rasterize_position_backward_tensor);

    m.def("rasterize_uv_sigmoid_k_randpos_forward", &rasterize_uv_sigmoid_k_randpos_forward_tensor);

    m.def("rasterize_uv_sigmoid_k_beta_forward", &rasterize_uv_sigmoid_k_beta_forward_tensor);
    m.def("rasterize_uv_sigmoid_k_beta_backward", &rasterize_uv_sigmoid_k_beta_backward_tensor);
}
