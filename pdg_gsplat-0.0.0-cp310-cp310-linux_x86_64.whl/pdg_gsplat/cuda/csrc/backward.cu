#include "backward.cuh"
#include "helpers.cuh"
#include <cuda_fp16.h>
#include <cooperative_groups.h>
#include <cooperative_groups/reduce.h>
namespace cg = cooperative_groups;

__global__ void rasterize_backward_kernel(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float3* __restrict__ conics,
    const float3* __restrict__ rgbs,
    const float* __restrict__ opacities,
    const int* __restrict__ final_index,
    const float3* __restrict__ v_output,
    const float* __restrict__ v_render_wsum,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_xy_abs,
    float3* __restrict__ v_conic,
    float3* __restrict__ v_rgb,
    float* __restrict__ v_opacity
) {
    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    const float px = (float)j + 0.5;
    const float py = (float)i + 0.5;
    // clamp this value to the last pixel
    const int32_t pix_id = min(i * img_size.x + j, img_size.x * img_size.y - 1);

    // keep not rasterizing threads around for reading data
    const bool inside = (i < img_size.y && j < img_size.x);

    // the contribution from gaussians behind the current one
    // float3 buffer = {0.f, 0.f, 0.f};
    // index of last gaussian to contribute to this pixel
    const int bin_final = inside? final_index[pix_id] : 0;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    const int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    const int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float3 conic_batch[MAX_BLOCK_SIZE];
    __shared__ float3 rgbs_batch[MAX_BLOCK_SIZE];
    __shared__ float opacity_batch[MAX_BLOCK_SIZE];

    // df/d_out for this pixel
    const float3 v_out = v_output[pix_id];
    const float v_render_w = v_render_wsum[pix_id];

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing
    const int tr = block.thread_rank();
    cg::thread_block_tile<32> warp = cg::tiled_partition<32>(block);
    const int warp_bin_final = cg::reduce(warp, bin_final, cg::greater<int>());
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before writing next batch of shared mem
        block.sync();

        // each thread fetch 1 gaussian from back to front
        // 0 index will be furthest back in batch
        // index of gaussian to load
        // batch end is the index of the last gaussian in the batch
        const int batch_end = range.y - 1 - block_size * b;
        int batch_size = min(block_size, batch_end + 1 - range.x);
        const int idx = batch_end - tr;
        if (idx >= range.x) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            conic_batch[tr] = conics[g_id];
            rgbs_batch[tr] = rgbs[g_id];
            opacity_batch[tr] = opacities ? opacities[g_id] : 1.0f;
        }
        // wait for other threads to collect the gaussians in batch
        block.sync();
        // process gaussians in the current batch for this pixel
        // 0 index is the furthest back gaussian in the batch
        for (int t = max(0,batch_end - warp_bin_final); t < batch_size; ++t) {
            int valid = inside;
            if (batch_end - t > bin_final) {
                valid = 0;
            }
            float alpha;
            float2 delta;
            float3 conic;
            float vis;
            if(valid){
                conic = conic_batch[t];
                const float opacity = opacity_batch[t];
                float2 xy = xy_batch[t];
                delta = {xy.x - px, xy.y - py};
                float sigma = 0.5f * (conic.x * delta.x * delta.x +
                                            conic.z * delta.y * delta.y) +
                                    conic.y * delta.x * delta.y;
                vis = __expf(-sigma);
                alpha = min(0.99f, opacity * vis);
                if (sigma < 0.f || alpha < 1.f / 255.f) {
                    valid = 0;
                }
            }
            // if all threads are inactive in this warp, skip this loop
            if(!warp.any(valid)){
                continue;
            }
            float3 v_rgb_local = {0.f, 0.f, 0.f};
            float3 v_conic_local = {0.f, 0.f, 0.f};
            float2 v_xy_local = {0.f, 0.f};
            float2 v_xy_abs_local = {0.f, 0.f};
            float v_opacity_local = 0.f;
            //initialize everything to 0, only set if the lane is valid
            if(valid){

                const float fac = alpha;
                float v_alpha = 0.f;
                v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};

                const float3 rgb = rgbs_batch[t];

                v_alpha += rgb.x * v_out.x;
                v_alpha += rgb.y * v_out.y;
                v_alpha += rgb.z * v_out.z; 
                
                // Gradient from weighted sum of alphas: ∂(Σ alpha_i)/∂alpha_i = 1
                v_alpha += v_render_w;

                // v_opacity = d(alpha)/d(opacity) * v_alpha = vis * v_alpha
                v_opacity_local = vis * v_alpha;

                const float v_sigma = -alpha * v_alpha;
                v_conic_local = {0.5f * v_sigma * delta.x * delta.x, 
                                 v_sigma * delta.x * delta.y,
                                 0.5f * v_sigma * delta.y * delta.y};

                v_xy_local = {v_sigma * (conic.x * delta.x + conic.y * delta.y), 
                                    v_sigma * (conic.y * delta.x + conic.z * delta.y)};
                v_xy_abs_local = {abs(v_xy_local.x), abs(v_xy_local.y)};
            }
            warpSum3(v_rgb_local, warp);
            warpSum3(v_conic_local, warp);
            warpSum2(v_xy_local, warp);
            warpSum2(v_xy_abs_local, warp);
            warpSum(v_opacity_local, warp);
            if (warp.thread_rank() == 0) {
                int32_t g = id_batch[t];
                float* v_rgb_ptr = (float*)(v_rgb);
                atomicAdd(v_rgb_ptr + 3*g + 0, v_rgb_local.x);
                atomicAdd(v_rgb_ptr + 3*g + 1, v_rgb_local.y);
                atomicAdd(v_rgb_ptr + 3*g + 2, v_rgb_local.z);
                
                float* v_conic_ptr = (float*)(v_conic);
                atomicAdd(v_conic_ptr + 3*g + 0, v_conic_local.x);
                atomicAdd(v_conic_ptr + 3*g + 1, v_conic_local.y);
                atomicAdd(v_conic_ptr + 3*g + 2, v_conic_local.z);
                
                float* v_xy_ptr = (float*)(v_xy);
                atomicAdd(v_xy_ptr + 2*g + 0, v_xy_local.x);
                atomicAdd(v_xy_ptr + 2*g + 1, v_xy_local.y);

                float* v_xy_abs_ptr = (float*)(v_xy_abs);
                atomicAdd(v_xy_abs_ptr + 2*g + 0, v_xy_abs_local.x);
                atomicAdd(v_xy_abs_ptr + 2*g + 1, v_xy_abs_local.y);
                
                if (v_opacity) {
                    atomicAdd(v_opacity + g, v_opacity_local);
                }
            }
        }
    }
}

__global__ void project_gaussians_backward_kernel(
    const int num_points,
    const float2* __restrict__ extents,
    const float3* __restrict__ conics,
    const float2* __restrict__ v_xy,
    const float3* __restrict__ v_conic,
    float3* __restrict__ v_cov2d,
    float2* __restrict__ v_mean2d
) {
    unsigned idx = cg::this_grid().thread_rank(); // idx of thread within grid
    if (idx >= num_points || (extents[idx].x <= 0.f || extents[idx].y <= 0.f)) {
        return;
    }

    v_mean2d[idx].x = v_xy[idx].x;
    v_mean2d[idx].y = v_xy[idx].y;

    // get v_cov2d
    cov2d_to_conic_vjp(conics[idx], v_conic[idx], v_cov2d[idx]);
}


__global__ void rasterize_sigmoid_backward_kernel(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float3* __restrict__ conics,
    const float3* __restrict__ rgbs,
    const float* __restrict__ opacities,
    const int* __restrict__ final_index,
    const float3* __restrict__ v_output,
    const float* __restrict__ v_render_wsum,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_xy_abs,
    float3* __restrict__ v_conic,
    float3* __restrict__ v_rgb,
    float* __restrict__ v_opacity
) {
    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    const float px = (float)j + 0.5;
    const float py = (float)i + 0.5;
    // clamp this value to the last pixel
    const int32_t pix_id = min(i * img_size.x + j, img_size.x * img_size.y - 1);

    // keep not rasterizing threads around for reading data
    const bool inside = (i < img_size.y && j < img_size.x);

    // the contribution from gaussians behind the current one
    // float3 buffer = {0.f, 0.f, 0.f};
    // index of last gaussian to contribute to this pixel
    const int bin_final = inside? final_index[pix_id] : 0;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    const int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    const int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float3 conic_batch[MAX_BLOCK_SIZE];
    __shared__ float3 rgbs_batch[MAX_BLOCK_SIZE];
    __shared__ float opacity_batch[MAX_BLOCK_SIZE];

    // df/d_out for this pixel
    const float3 v_out = v_output[pix_id];
    const float v_render_w = v_render_wsum[pix_id];

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing
    const int tr = block.thread_rank();
    cg::thread_block_tile<32> warp = cg::tiled_partition<32>(block);
    const int warp_bin_final = cg::reduce(warp, bin_final, cg::greater<int>());
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before writing next batch of shared mem
        block.sync();

        // each thread fetch 1 gaussian from back to front
        // 0 index will be furthest back in batch
        // index of gaussian to load
        // batch end is the index of the last gaussian in the batch
        const int batch_end = range.y - 1 - block_size * b;
        int batch_size = min(block_size, batch_end + 1 - range.x);
        const int idx = batch_end - tr;
        if (idx >= range.x) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            conic_batch[tr] = conics[g_id];
            rgbs_batch[tr] = rgbs[g_id];
            opacity_batch[tr] = opacities ? opacities[g_id] : 1.0f;
        }
        // wait for other threads to collect the gaussians in batch
        block.sync();
        // process gaussians in the current batch for this pixel
        // 0 index is the furthest back gaussian in the batch
        for (int t = max(0,batch_end - warp_bin_final); t < batch_size; ++t) {
            int valid = inside;
            if (batch_end - t > bin_final) {
                valid = 0;
            }
            float alpha;
            float2 delta;
            float3 conic;
            float vis;
            float gate_x;
            float gate_y;
            if(valid){
                conic = conic_batch[t];
                const float opacity = opacity_batch[t];
                float2 xy = xy_batch[t];
                delta = {xy.x - px, xy.y - py};
                float sigma = 0.5f * (conic.x * delta.x * delta.x +
                                            conic.z * delta.y * delta.y) +
                                    conic.y * delta.x * delta.y;
                vis = __expf(-sigma);
                gate_x = sigmoid_k((float)SIGMOID_K,  delta.x);
                gate_y = sigmoid_k((float)SIGMOID_K,  delta.y);

                //alpha = min(0.99f, opacity * vis * gate_x * gate_y);
                alpha = opacity * vis * gate_x * gate_y;
                if (sigma < 0.f || alpha < 1.f / 255.f) {
                    valid = 0;
                }
            }
            // if all threads are inactive in this warp, skip this loop
            if(!warp.any(valid)){
                continue;
            }
            float3 v_rgb_local = {0.f, 0.f, 0.f};
            float3 v_conic_local = {0.f, 0.f, 0.f};
            float2 v_xy_local = {0.f, 0.f};
            float2 v_xy_abs_local = {0.f, 0.f};
            float v_opacity_local = 0.f;
            //initialize everything to 0, only set if the lane is valid
            if(valid){

                const float fac = alpha;
                float v_alpha = 0.f;
                v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};

                const float3 rgb = rgbs_batch[t];

                v_alpha += rgb.x * v_out.x;
                v_alpha += rgb.y * v_out.y;
                v_alpha += rgb.z * v_out.z;

                // Gradient from weighted sum of alphas: ∂(Σ alpha_i)/∂alpha_i = 1
                v_alpha += v_render_w;

                // v_opacity = d(alpha)/d(opacity) * v_alpha = vis * v_alpha
                v_opacity_local = vis * v_alpha * gate_x * gate_y;  // !!!!!!!!!!!!!

                const float v_sigma = -alpha * v_alpha;
                v_conic_local = {0.5f * v_sigma * delta.x * delta.x,
                                 v_sigma * delta.x * delta.y,
                                 0.5f * v_sigma * delta.y * delta.y};

//                 v_xy_local = {v_sigma * (conic.x * delta.x + conic.y * delta.y),
//                                     v_sigma * (conic.y * delta.x + conic.z * delta.y)};
                // !!!!!!!!!!!!!!!!
                v_xy_local.x = v_alpha * alpha * (-(conic.x * delta.x + conic.y * delta.y) + SIGMOID_K * (1 - gate_x));
                v_xy_local.y = v_alpha * alpha * (-(conic.y * delta.x + conic.z * delta.y) + SIGMOID_K * (1 - gate_y));

                v_xy_abs_local = {abs(v_xy_local.x), abs(v_xy_local.y)};
            }
            warpSum3(v_rgb_local, warp);
            warpSum3(v_conic_local, warp);
            warpSum2(v_xy_local, warp);
            warpSum2(v_xy_abs_local, warp);
            warpSum(v_opacity_local, warp);
            if (warp.thread_rank() == 0) {
                int32_t g = id_batch[t];
                float* v_rgb_ptr = (float*)(v_rgb);
                atomicAdd(v_rgb_ptr + 3*g + 0, v_rgb_local.x);
                atomicAdd(v_rgb_ptr + 3*g + 1, v_rgb_local.y);
                atomicAdd(v_rgb_ptr + 3*g + 2, v_rgb_local.z);

                float* v_conic_ptr = (float*)(v_conic);
                atomicAdd(v_conic_ptr + 3*g + 0, v_conic_local.x);
                atomicAdd(v_conic_ptr + 3*g + 1, v_conic_local.y);
                atomicAdd(v_conic_ptr + 3*g + 2, v_conic_local.z);

                float* v_xy_ptr = (float*)(v_xy);
                atomicAdd(v_xy_ptr + 2*g + 0, v_xy_local.x);
                atomicAdd(v_xy_ptr + 2*g + 1, v_xy_local.y);

                float* v_xy_abs_ptr = (float*)(v_xy_abs);
                atomicAdd(v_xy_abs_ptr + 2*g + 0, v_xy_abs_local.x);
                atomicAdd(v_xy_abs_ptr + 2*g + 1, v_xy_abs_local.y);

                if (v_opacity) {
                    atomicAdd(v_opacity + g, v_opacity_local);
                }
            }
        }
    }
}


__global__ void rasterize_uv_backward_kernel(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float3* __restrict__ rgbs,
    const int* __restrict__ final_index,
    const float3* __restrict__ v_output,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_log_scales,
    float* __restrict__ v_thetas,
    float3* __restrict__ v_rgb
) {
    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    const float px = (float)j + 0.5;
    const float py = (float)i + 0.5;
    // clamp this value to the last pixel
    const int32_t pix_id = min(i * img_size.x + j, img_size.x * img_size.y - 1);

    // keep not rasterizing threads around for reading data
    const bool inside = (i < img_size.y && j < img_size.x);

    // the contribution from gaussians behind the current one
    // float3 buffer = {0.f, 0.f, 0.f};
    // index of last gaussian to contribute to this pixel
    const int bin_final = inside? final_index[pix_id] : 0;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    const int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    const int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float3 rgbs_batch[MAX_BLOCK_SIZE];

    // df/d_out for this pixel
    const float3 v_out = v_output[pix_id];

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing
    const int tr = block.thread_rank();
    cg::thread_block_tile<32> warp = cg::tiled_partition<32>(block);
    const int warp_bin_final = cg::reduce(warp, bin_final, cg::greater<int>());
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before writing next batch of shared mem
        block.sync();

        // each thread fetch 1 gaussian from back to front
        // 0 index will be furthest back in batch
        // index of gaussian to load
        // batch end is the index of the last gaussian in the batch
        const int batch_end = range.y - 1 - block_size * b;
        int batch_size = min(block_size, batch_end + 1 - range.x);
        const int idx = batch_end - tr;
        if (idx >= range.x) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
            rgbs_batch[tr] = rgbs[g_id];
        }
        // wait for other threads to collect the gaussians in batch
        block.sync();
        // process gaussians in the current batch for this pixel
        // 0 index is the furthest back gaussian in the batch
        for (int t = max(0,batch_end - warp_bin_final); t < batch_size; ++t) {
            int valid = inside;
            if (batch_end - t > bin_final) {
                valid = 0;
            }
            float alpha;
            float2 delta;
            float2 log_scale;
            float theta;
            float uu;
            float vv;
            float inv_sx;
            float inv_sy;
            float ssin;
            float ccos;
            if(valid){
                float2 log_scale = log_scales_batch[t];
                float theta = thetas_batch[t];
                float2 xy = xy_batch[t];
                delta = {xy.x - px, xy.y - py};

                inv_sx = __expf(-log_scale.x);
                inv_sy = __expf(-log_scale.y);
                __sincosf(theta, &ssin, &ccos);

                uu = (ccos * delta.x + ssin * delta.y);
                vv = (-ssin * delta.x + ccos * delta.y);
                float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);

                alpha = __expf(-sigma);
                if (sigma < 0.f || alpha < 1.f / 255.f) {
                    valid = 0;
                }
            }
            // if all threads are inactive in this warp, skip this loop
            if(!warp.any(valid)){
                continue;
            }
            float3 v_rgb_local = {0.f, 0.f, 0.f};
            float2 v_log_scales_local = {0.f, 0.f};
            float2 v_xy_local = {0.f, 0.f};
            float v_thetas_local = 0.f;
            //initialize everything to 0, only set if the lane is valid
            if(valid){

                const float fac = alpha;
                float v_alpha = 0.f;
                v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};

                const float3 rgb = rgbs_batch[t];

                v_alpha += rgb.x * v_out.x;
                v_alpha += rgb.y * v_out.y;
                v_alpha += rgb.z * v_out.z;
                const float v_sigma = -alpha * v_alpha;

                v_thetas_local = v_sigma * (uu * vv * (inv_sx * inv_sx - inv_sy * inv_sy));

                v_xy_local.x = v_sigma * (uu * inv_sx * inv_sx * ccos - vv * inv_sy * inv_sy * ssin);
                v_xy_local.y = v_sigma * (uu * inv_sx * inv_sx * ssin + vv * inv_sy * inv_sy * ccos);

                v_log_scales_local.x = v_sigma * (-uu * uu * inv_sx * inv_sx);
                v_log_scales_local.y = v_sigma * (-vv * vv * inv_sy * inv_sy);
            }
            warpSum3(v_rgb_local, warp);
            warpSum2(v_xy_local, warp);
            warpSum2(v_log_scales_local, warp);
            warpSum(v_thetas_local, warp);
            if (warp.thread_rank() == 0) {
                int32_t g = id_batch[t];
                float* v_rgb_ptr = (float*)(v_rgb);
                atomicAdd(v_rgb_ptr + 3*g + 0, v_rgb_local.x);
                atomicAdd(v_rgb_ptr + 3*g + 1, v_rgb_local.y);
                atomicAdd(v_rgb_ptr + 3*g + 2, v_rgb_local.z);

                float* v_xy_ptr = (float*)(v_xy);
                atomicAdd(v_xy_ptr + 2*g + 0, v_xy_local.x);
                atomicAdd(v_xy_ptr + 2*g + 1, v_xy_local.y);

                float* v_log_scales_ptr = (float*)(v_log_scales);
                atomicAdd(v_log_scales_ptr + 2*g + 0, v_log_scales_local.x);
                atomicAdd(v_log_scales_ptr + 2*g + 1, v_log_scales_local.y);

                atomicAdd(v_thetas + g, v_thetas_local);
            }
        }
    }
}


__global__ void rasterize_uv_sigmoid_backward_kernel(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float3* __restrict__ rgbs,
    const int* __restrict__ final_index,
    const float3* __restrict__ v_output,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_log_scales,
    float* __restrict__ v_thetas,
    float3* __restrict__ v_rgb
) {
    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    const float px = (float)j + 0.5;
    const float py = (float)i + 0.5;
    // clamp this value to the last pixel
    const int32_t pix_id = min(i * img_size.x + j, img_size.x * img_size.y - 1);

    // keep not rasterizing threads around for reading data
    const bool inside = (i < img_size.y && j < img_size.x);

    // the contribution from gaussians behind the current one
    // float3 buffer = {0.f, 0.f, 0.f};
    // index of last gaussian to contribute to this pixel
    const int bin_final = inside? final_index[pix_id] : 0;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    const int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    const int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float3 rgbs_batch[MAX_BLOCK_SIZE];

    // df/d_out for this pixel
    const float3 v_out = v_output[pix_id];

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing
    const int tr = block.thread_rank();
    cg::thread_block_tile<32> warp = cg::tiled_partition<32>(block);
    const int warp_bin_final = cg::reduce(warp, bin_final, cg::greater<int>());
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before writing next batch of shared mem
        block.sync();

        // each thread fetch 1 gaussian from back to front
        // 0 index will be furthest back in batch
        // index of gaussian to load
        // batch end is the index of the last gaussian in the batch
        const int batch_end = range.y - 1 - block_size * b;
        int batch_size = min(block_size, batch_end + 1 - range.x);
        const int idx = batch_end - tr;
        if (idx >= range.x) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
            rgbs_batch[tr] = rgbs[g_id];
        }
        // wait for other threads to collect the gaussians in batch
        block.sync();
        // process gaussians in the current batch for this pixel
        // 0 index is the furthest back gaussian in the batch
        for (int t = max(0,batch_end - warp_bin_final); t < batch_size; ++t) {
            int valid = inside;
            if (batch_end - t > bin_final) {
                valid = 0;
            }
            float alpha;
            float2 delta;
            float2 log_scale;
            float theta;
            float uu, vv, inv_sx, inv_sy, ssin, ccos, mx, my;
            if(valid){
                float2 log_scale = log_scales_batch[t];
                float theta = thetas_batch[t];
                float2 xy = xy_batch[t];
                delta = {xy.x - px, xy.y - py};

                inv_sx = __expf(-log_scale.x);
                inv_sy = __expf(-log_scale.y);
                __sincosf(theta, &ssin, &ccos);

                uu = (ccos * delta.x + ssin * delta.y);
                vv = (-ssin * delta.x + ccos * delta.y);
                float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);

                mx = sigmoid_k((float)SIGMOID_K,  uu);
                my = sigmoid_k((float)SIGMOID_K,  vv);

                alpha = __expf(-sigma) * mx * my;
                if (sigma < 0.f || alpha < 1.f / 255.f) {
                    valid = 0;
                }
            }
            // if all threads are inactive in this warp, skip this loop
            if(!warp.any(valid)){
                continue;
            }
            float3 v_rgb_local = {0.f, 0.f, 0.f};
            float2 v_log_scales_local = {0.f, 0.f};
            float2 v_xy_local = {0.f, 0.f};
            float v_thetas_local = 0.f;
            //initialize everything to 0, only set if the lane is valid
            if(valid){

                const float fac = alpha;
                float v_alpha = 0.f;
                v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};

                const float3 rgb = rgbs_batch[t];

                v_alpha += rgb.x * v_out.x;
                v_alpha += rgb.y * v_out.y;
                v_alpha += rgb.z * v_out.z;

                v_thetas_local = v_alpha * (-fac) * (uu * vv * (inv_sx * inv_sx - inv_sy * inv_sy) - (1 - mx) * (float)SIGMOID_K * vv + (1 - my) * (float)SIGMOID_K * uu);

                v_xy_local.x = v_alpha * (-fac) * (uu * inv_sx * inv_sx * ccos - vv * inv_sy * inv_sy * ssin - (1 - mx) * (float)SIGMOID_K * ccos + (1 - my) * (float)SIGMOID_K * ssin);
                v_xy_local.y = v_alpha * (-fac) * (uu * inv_sx * inv_sx * ssin + vv * inv_sy * inv_sy * ccos - (1 - mx) * (float)SIGMOID_K * ssin - (1 - my) * (float)SIGMOID_K * ccos);

                v_log_scales_local.x = v_alpha * fac * uu * uu * inv_sx * inv_sx;
                v_log_scales_local.y = v_alpha * fac * vv * vv * inv_sy * inv_sy;

//                 const float v_sigma = -alpha * v_alpha;
//
//                 v_thetas_local = v_sigma * (uu * vv * (inv_sx * inv_sx - inv_sy * inv_sy));
//
//                 v_xy_local.x = v_sigma * (uu * inv_sx * inv_sx * ccos - vv * inv_sy * inv_sy * ssin);
//                 v_xy_local.y = v_sigma * (uu * inv_sx * inv_sx * ssin + vv * inv_sy * inv_sy * ccos);
//
//                 v_log_scales_local.x = v_sigma * (-uu * uu * inv_sx * inv_sx);
//                 v_log_scales_local.y = v_sigma * (-vv * vv * inv_sy * inv_sy);
            }
            warpSum3(v_rgb_local, warp);
            warpSum2(v_xy_local, warp);
            warpSum2(v_log_scales_local, warp);
            warpSum(v_thetas_local, warp);
            if (warp.thread_rank() == 0) {
                int32_t g = id_batch[t];
                float* v_rgb_ptr = (float*)(v_rgb);
                atomicAdd(v_rgb_ptr + 3*g + 0, v_rgb_local.x);
                atomicAdd(v_rgb_ptr + 3*g + 1, v_rgb_local.y);
                atomicAdd(v_rgb_ptr + 3*g + 2, v_rgb_local.z);

                float* v_xy_ptr = (float*)(v_xy);
                atomicAdd(v_xy_ptr + 2*g + 0, v_xy_local.x);
                atomicAdd(v_xy_ptr + 2*g + 1, v_xy_local.y);

                float* v_log_scales_ptr = (float*)(v_log_scales);
                atomicAdd(v_log_scales_ptr + 2*g + 0, v_log_scales_local.x);
                atomicAdd(v_log_scales_ptr + 2*g + 1, v_log_scales_local.y);

                atomicAdd(v_thetas + g, v_thetas_local);
            }
        }
    }
}


__global__ void rasterize_uv_sigmoid_k_backward_kernel(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float3* __restrict__ rgbs,
    const int* __restrict__ final_index,
    const float3* __restrict__ v_output,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_log_scales,
    float* __restrict__ v_thetas,
    float2* __restrict__ v_sig_k,
    float3* __restrict__ v_rgb
) {
    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    const float px = (float)j + 0.5;
    const float py = (float)i + 0.5;
    // clamp this value to the last pixel
    const int32_t pix_id = min(i * img_size.x + j, img_size.x * img_size.y - 1);

    // keep not rasterizing threads around for reading data
    const bool inside = (i < img_size.y && j < img_size.x);

    // the contribution from gaussians behind the current one
    // float3 buffer = {0.f, 0.f, 0.f};
    // index of last gaussian to contribute to this pixel
    const int bin_final = inside? final_index[pix_id] : 0;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    const int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    const int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float3 rgbs_batch[MAX_BLOCK_SIZE];
    __shared__ float2 sig_k_batch[MAX_BLOCK_SIZE];

    // df/d_out for this pixel
    const float3 v_out = v_output[pix_id];

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing
    const int tr = block.thread_rank();
    cg::thread_block_tile<32> warp = cg::tiled_partition<32>(block);
    const int warp_bin_final = cg::reduce(warp, bin_final, cg::greater<int>());
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before writing next batch of shared mem
        block.sync();

        // each thread fetch 1 gaussian from back to front
        // 0 index will be furthest back in batch
        // index of gaussian to load
        // batch end is the index of the last gaussian in the batch
        const int batch_end = range.y - 1 - block_size * b;
        int batch_size = min(block_size, batch_end + 1 - range.x);
        const int idx = batch_end - tr;
        if (idx >= range.x) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
            rgbs_batch[tr] = rgbs[g_id];
            sig_k_batch[tr] = sig_k[g_id];
        }
        // wait for other threads to collect the gaussians in batch
        block.sync();
        // process gaussians in the current batch for this pixel
        // 0 index is the furthest back gaussian in the batch
        for (int t = max(0,batch_end - warp_bin_final); t < batch_size; ++t) {
            int valid = inside;
            if (batch_end - t > bin_final) {
                valid = 0;
            }
            float alpha;
            float2 delta;
            float2 sig_k_one;
            float uu, vv, inv_sx, inv_sy, ssin, ccos, mx, my;
            if(valid){
                float2 log_scale = log_scales_batch[t];
                float theta = thetas_batch[t];
                float2 xy = xy_batch[t];
                delta = {xy.x - px, xy.y - py};
                sig_k_one = sig_k_batch[t];

                inv_sx = __expf(-log_scale.x);
                inv_sy = __expf(-log_scale.y);
                __sincosf(theta, &ssin, &ccos);

                uu = (ccos * delta.x + ssin * delta.y);
                vv = (-ssin * delta.x + ccos * delta.y);
                float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);

                mx = sigmoid_k(sig_k_one.x,  uu);
                my = sigmoid_k(sig_k_one.y,  vv);

                alpha = __expf(-sigma) * mx * my;
                if (sigma < 0.f || alpha < 1.f / 255.f) {
                    valid = 0;
                }
            }
            // if all threads are inactive in this warp, skip this loop
            if(!warp.any(valid)){
                continue;
            }
            float3 v_rgb_local = {0.f, 0.f, 0.f};
            float2 v_log_scales_local = {0.f, 0.f};
            float2 v_xy_local = {0.f, 0.f};
            float v_thetas_local = 0.f;
            float2 v_sig_k_local = {0.f, 0.f};
            //initialize everything to 0, only set if the lane is valid
            if(valid){

                const float fac = alpha;
                float v_alpha = 0.f;
                v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};

                const float3 rgb = rgbs_batch[t];

                v_alpha += rgb.x * v_out.x;
                v_alpha += rgb.y * v_out.y;
                v_alpha += rgb.z * v_out.z;

                v_thetas_local = v_alpha * (-fac) * (uu * vv * (inv_sx * inv_sx - inv_sy * inv_sy) - (1 - mx) * sig_k_one.x * vv + (1 - my) * sig_k_one.y * uu);

                v_xy_local.x = v_alpha * (-fac) * (uu * inv_sx * inv_sx * ccos - vv * inv_sy * inv_sy * ssin - (1 - mx) * sig_k_one.x * ccos + (1 - my) * sig_k_one.y * ssin);
                v_xy_local.y = v_alpha * (-fac) * (uu * inv_sx * inv_sx * ssin + vv * inv_sy * inv_sy * ccos - (1 - mx) * sig_k_one.x * ssin - (1 - my) * sig_k_one.y * ccos);

                v_log_scales_local.x = v_alpha * fac * uu * uu * inv_sx * inv_sx;
                v_log_scales_local.y = v_alpha * fac * vv * vv * inv_sy * inv_sy;

                v_sig_k_local.x = v_alpha * fac * (1 - mx) * uu;
                v_sig_k_local.y = v_alpha * fac * (1 - my) * vv;
            }
            warpSum3(v_rgb_local, warp);
            warpSum2(v_xy_local, warp);
            warpSum2(v_log_scales_local, warp);
            warpSum(v_thetas_local, warp);
            warpSum2(v_sig_k_local, warp);
            if (warp.thread_rank() == 0) {
                int32_t g = id_batch[t];
                float* v_rgb_ptr = (float*)(v_rgb);
                atomicAdd(v_rgb_ptr + 3*g + 0, v_rgb_local.x);
                atomicAdd(v_rgb_ptr + 3*g + 1, v_rgb_local.y);
                atomicAdd(v_rgb_ptr + 3*g + 2, v_rgb_local.z);

                float* v_xy_ptr = (float*)(v_xy);
                atomicAdd(v_xy_ptr + 2*g + 0, v_xy_local.x);
                atomicAdd(v_xy_ptr + 2*g + 1, v_xy_local.y);

                float* v_log_scales_ptr = (float*)(v_log_scales);
                atomicAdd(v_log_scales_ptr + 2*g + 0, v_log_scales_local.x);
                atomicAdd(v_log_scales_ptr + 2*g + 1, v_log_scales_local.y);

                atomicAdd(v_thetas + g, v_thetas_local);

                float* v_sig_k_ptr = (float*)(v_sig_k);
                atomicAdd(v_sig_k_ptr + 2*g + 0, v_sig_k_local.x);
                atomicAdd(v_sig_k_ptr + 2*g + 1, v_sig_k_local.y);
            }
        }
    }
}




__global__ void rasterize_position_backward_kernel(
    const int pix_num,
    const dim3 tile_bounds,
    const dim3 tile_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float3* __restrict__ rgbs,
    const float* __restrict__ pxs,
    const float* __restrict__ pys,
    const int* __restrict__ final_index,
    const float3* __restrict__ v_output,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_log_scales,
    float* __restrict__ v_thetas,
    float2* __restrict__ v_sig_k,
    float3* __restrict__ v_rgb
) {

    unsigned idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= pix_num)
        return;

    float px = pxs[idx];
    float py = pys[idx];
    int tile_x = (int)(px / (float)tile_size.x);
    int tile_y = (int)(py / (float)tile_size.y);
    if (tile_x < 0 || tile_x >= (int)tile_bounds.x || tile_y < 0 || tile_y >= (int)tile_bounds.y) {
        return;
    }
    int32_t tile_id = tile_y * (int)tile_bounds.x + tile_x;
    int2 range = tile_bins[tile_id];

    // df/d_out for this pixel
    const float3 v_out = v_output[idx];

    for (int p = range.x; p < range.y; ++p) {
        int32_t g_id = gaussian_ids_sorted[p];
        const float2 log_scale = log_scales[g_id];
        const float2 sig_k_one = sig_k[g_id];
        const float  theta     = thetas[g_id];
        const float2 xy        = xys[g_id];
        const float3 rgb = rgbs[g_id];

        const float2 delta = {xy.x - px, xy.y - py};
        const float inv_sx = __expf(-log_scale.x);
        const float inv_sy = __expf(-log_scale.y);

        float ssin, ccos;
        __sincosf(theta, &ssin, &ccos);

        const float uu = (ccos * delta.x + ssin * delta.y);
        const float vv = (-ssin * delta.x + ccos * delta.y);
        const float sigma = 0.5f * (uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy);
        const float mx = sigmoid_k(sig_k_one.x, uu);
        const float my = sigmoid_k(sig_k_one.y, vv);
        const float alpha = __expf(-sigma) * mx * my;

        float3 v_rgb_local = {0.f, 0.f, 0.f};
        float2 v_log_scales_local = {0.f, 0.f};
        float2 v_xy_local = {0.f, 0.f};
        float v_thetas_local = 0.f;
        float2 v_sig_k_local = {0.f, 0.f};

        const float fac = alpha;
        float v_alpha = 0.f;
        v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};

        v_alpha += rgb.x * v_out.x;
        v_alpha += rgb.y * v_out.y;
        v_alpha += rgb.z * v_out.z;

        v_thetas_local = v_alpha * (-fac) * (uu * vv * (inv_sx * inv_sx - inv_sy * inv_sy) - (1 - mx) * sig_k_one.x * vv + (1 - my) * sig_k_one.y * uu);

        v_xy_local.x = v_alpha * (-fac) * (uu * inv_sx * inv_sx * ccos - vv * inv_sy * inv_sy * ssin - (1 - mx) * sig_k_one.x * ccos + (1 - my) * sig_k_one.y * ssin);
        v_xy_local.y = v_alpha * (-fac) * (uu * inv_sx * inv_sx * ssin + vv * inv_sy * inv_sy * ccos - (1 - mx) * sig_k_one.x * ssin - (1 - my) * sig_k_one.y * ccos);

        v_log_scales_local.x = v_alpha * fac * uu * uu * inv_sx * inv_sx;
        v_log_scales_local.y = v_alpha * fac * vv * vv * inv_sy * inv_sy;

        v_sig_k_local.x = v_alpha * fac * (1 - mx) * uu;
        v_sig_k_local.y = v_alpha * fac * (1 - my) * vv;

         // atomic add to global grads
        // rgb
        atomicAdd(((float*)v_rgb) + 3 * g_id + 0, v_rgb_local.x);
        atomicAdd(((float*)v_rgb) + 3 * g_id + 1, v_rgb_local.y);
        atomicAdd(((float*)v_rgb) + 3 * g_id + 2, v_rgb_local.z);

        // xy
        atomicAdd(((float*)v_xy) + 2 * g_id + 0, v_xy_local.x);
        atomicAdd(((float*)v_xy) + 2 * g_id + 1, v_xy_local.y);

        // log_scales
        atomicAdd(((float*)v_log_scales) + 2 * g_id + 0, v_log_scales_local.x);
        atomicAdd(((float*)v_log_scales) + 2 * g_id + 1, v_log_scales_local.y);

        // thetas
        atomicAdd(v_thetas + g_id, v_thetas_local);

        // sig_k
        atomicAdd(((float*)v_sig_k) + 2 * g_id + 0, v_sig_k_local.x);
        atomicAdd(((float*)v_sig_k) + 2 * g_id + 1, v_sig_k_local.y);

    }
}



__global__ void rasterize_uv_sigmoid_k_beta_backward_kernel(
    const dim3 tile_bounds,
    const dim3 img_size,
    const int32_t* __restrict__ gaussian_ids_sorted,
    const int2* __restrict__ tile_bins,
    const float2* __restrict__ xys,
    const float2* __restrict__ log_scales,
    const float* __restrict__ thetas,
    const float2* __restrict__ sig_k,
    const float* __restrict__ betas,
    const float* __restrict__ rgbs,
    int channels,
    const int* __restrict__ final_index,
    const float* __restrict__ v_output,
    float2* __restrict__ v_xy,
    float2* __restrict__ v_log_scales,
    float* __restrict__ v_thetas,
    float2* __restrict__ v_sig_k,
    float* __restrict__ v_betas,
    float* __restrict__ v_rgb
) {
    auto block = cg::this_thread_block();
    int32_t tile_id =
        block.group_index().y * tile_bounds.x + block.group_index().x;
    unsigned i =
        block.group_index().y * block.group_dim().y + block.thread_index().y;
    unsigned j =
        block.group_index().x * block.group_dim().x + block.thread_index().x;

    const float px = (float)j + 0.5;
    const float py = (float)i + 0.5;
    // clamp this value to the last pixel
    const int32_t pix_id = min(i * img_size.x + j, img_size.x * img_size.y - 1);

    // keep not rasterizing threads around for reading data
    const bool inside = (i < img_size.y && j < img_size.x);

    // the contribution from gaussians behind the current one
    // float3 buffer = {0.f, 0.f, 0.f};
    // index of last gaussian to contribute to this pixel
    const int bin_final = inside? final_index[pix_id] : 0;

    // have all threads in tile process the same gaussians in batches
    // first collect gaussians between range.x and range.y in batches
    // which gaussians to look through in this tile
    const int2 range = tile_bins[tile_id];
    const int block_size = block.size();
    const int num_batches = (range.y - range.x + block_size - 1) / block_size;

    __shared__ int32_t id_batch[MAX_BLOCK_SIZE];
    __shared__ float2 xy_batch[MAX_BLOCK_SIZE];
    __shared__ float2 log_scales_batch[MAX_BLOCK_SIZE];
    __shared__ float thetas_batch[MAX_BLOCK_SIZE];
    __shared__ float2 sig_k_batch[MAX_BLOCK_SIZE];
    __shared__ float betas_batch[MAX_BLOCK_SIZE];

    // df/d_out for this pixel
//     const float3 v_out = v_output[pix_id];
    const float* v_out_ptr = v_output + (int64_t)pix_id * channels;

    // collect and process batches of gaussians
    // each thread loads one gaussian at a time before rasterizing
    const int tr = block.thread_rank();
    cg::thread_block_tile<32> warp = cg::tiled_partition<32>(block);
    const int warp_bin_final = cg::reduce(warp, bin_final, cg::greater<int>());
    for (int b = 0; b < num_batches; ++b) {
        // resync all threads before writing next batch of shared mem
        block.sync();

        // each thread fetch 1 gaussian from back to front
        // 0 index will be furthest back in batch
        // index of gaussian to load
        // batch end is the index of the last gaussian in the batch
        const int batch_end = range.y - 1 - block_size * b;
        int batch_size = min(block_size, batch_end + 1 - range.x);
        const int idx = batch_end - tr;
        if (idx >= range.x) {
            int32_t g_id = gaussian_ids_sorted[idx];
            id_batch[tr] = g_id;
            xy_batch[tr] = xys[g_id];
            log_scales_batch[tr] = log_scales[g_id];
            thetas_batch[tr] = thetas[g_id];
//             rgbs_batch[tr] = rgbs[g_id];
            sig_k_batch[tr] = sig_k[g_id];
            betas_batch[tr] = betas[g_id];
        }
        // wait for other threads to collect the gaussians in batch
        block.sync();
        // process gaussians in the current batch for this pixel
        // 0 index is the furthest back gaussian in the batch
        for (int t = max(0,batch_end - warp_bin_final); t < batch_size; ++t) {
            int valid = inside;
            if (batch_end - t > bin_final) {
                valid = 0;
            }
            float alpha;
            float2 delta;
            float2 sig_k_one;
            float uu, vv, inv_sx, inv_sy, ssin, ccos, mx, my;
            float sigma, beta, sigma_beta, sigma_beta_1;
            constexpr float eps = 1e-6f;
            if(valid){
                float2 log_scale = log_scales_batch[t];
                float theta = thetas_batch[t];
                float2 xy = xy_batch[t];
                beta = betas_batch[t];
                delta = {xy.x - px, xy.y - py};
                sig_k_one = sig_k_batch[t];

                inv_sx = __expf(-log_scale.x);
                inv_sy = __expf(-log_scale.y);
                __sincosf(theta, &ssin, &ccos);

                uu = (ccos * delta.x + ssin * delta.y);
                vv = (-ssin * delta.x + ccos * delta.y);
                sigma = uu * uu * inv_sx * inv_sx + vv * vv * inv_sy * inv_sy + eps;

                mx = sigmoid_k(sig_k_one.x,  uu);
                my = sigmoid_k(sig_k_one.y,  vv);

                sigma_beta = __powf(sigma, beta);
                sigma_beta_1 = __powf(sigma, beta - 1.0);
                alpha = __expf(-0.5 * sigma_beta) * mx * my;
                if (sigma < 0.f || alpha < 1.f / 255.f) {
                    valid = 0;
                }
            }
            // if all threads are inactive in this warp, skip this loop
            if(!warp.any(valid)){
                continue;
            }
//             float3 v_rgb_local = {0.f, 0.f, 0.f};
            float v_rgb_local[8];
            #pragma unroll
            for (int c = 0; c < 8; ++c) v_rgb_local[c] = 0.f;

            float2 v_log_scales_local = {0.f, 0.f};
            float2 v_xy_local = {0.f, 0.f};
            float v_thetas_local = 0.f;
            float2 v_sig_k_local = {0.f, 0.f};
            float v_betas_local = 0.f;
            //initialize everything to 0, only set if the lane is valid
            if(valid){

                const float fac = alpha;
                float v_alpha = 0.f;

//                 v_rgb_local = {fac * v_out.x, fac * v_out.y, fac * v_out.z};
//                 const float3 rgb = rgbs_batch[t];
                const int32_t g = id_batch[t];
                const float* rgb_ptr = rgbs + (int64_t)g * channels;
                #pragma unroll 1
                for (int c = 0; c < channels; ++c) {
                    const float vout_c = v_out_ptr[c];
                    v_rgb_local[c] = fac * vout_c;
                    v_alpha += rgb_ptr[c] * vout_c;
                }

//                 v_alpha += rgb.x * v_out.x;
//                 v_alpha += rgb.y * v_out.y;
//                 v_alpha += rgb.z * v_out.z;

                v_thetas_local = v_alpha * (-fac) * (beta * sigma_beta_1 * uu * vv * (inv_sx * inv_sx - inv_sy * inv_sy) - (1 - mx) * sig_k_one.x * vv + (1 - my) * sig_k_one.y * uu);

                v_xy_local.x = v_alpha * (-fac) * (beta * sigma_beta_1 * (uu * inv_sx * inv_sx * ccos - vv * inv_sy * inv_sy * ssin) - (1 - mx) * sig_k_one.x * ccos + (1 - my) * sig_k_one.y * ssin);
                v_xy_local.y = v_alpha * (-fac) * (beta * sigma_beta_1 * (uu * inv_sx * inv_sx * ssin + vv * inv_sy * inv_sy * ccos) - (1 - mx) * sig_k_one.x * ssin - (1 - my) * sig_k_one.y * ccos);

                v_log_scales_local.x = v_alpha * fac * beta * sigma_beta_1 * uu * uu * inv_sx * inv_sx;
                v_log_scales_local.y = v_alpha * fac * beta * sigma_beta_1 * vv * vv * inv_sy * inv_sy;

                v_sig_k_local.x = v_alpha * fac * (1 - mx) * uu;
                v_sig_k_local.y = v_alpha * fac * (1 - my) * vv;

                v_betas_local = -0.5 * sigma_beta * fac * __logf(sigma) * v_alpha;
            }
//             warpSum3(v_rgb_local, warp);
            warpSum2(v_xy_local, warp);
            warpSum2(v_log_scales_local, warp);
            warpSum(v_thetas_local, warp);
            warpSum2(v_sig_k_local, warp);
            warpSum(v_betas_local, warp);

            // warp reduce：v_rgb_local 逐通道求和
            #pragma unroll 1
            for (int c = 0; c < channels; ++c) {
                v_rgb_local[c] = cg::reduce(warp, v_rgb_local[c], cg::plus<float>());
            }


            if (warp.thread_rank() == 0) {
                int32_t g = id_batch[t];

//                 float* v_rgb_ptr = (float*)(v_rgb);
//                 atomicAdd(v_rgb_ptr + 3*g + 0, v_rgb_local.x);
//                 atomicAdd(v_rgb_ptr + 3*g + 1, v_rgb_local.y);
//                 atomicAdd(v_rgb_ptr + 3*g + 2, v_rgb_local.z);
                // v_rgb 原子加：逐通道 atomicAdd
                float* v_rgb_ptr = v_rgb + (int64_t)g * channels;
                #pragma unroll 1
                for (int c = 0; c < channels; ++c) {
                    atomicAdd(v_rgb_ptr + c, v_rgb_local[c]);
                }

                float* v_xy_ptr = (float*)(v_xy);
                atomicAdd(v_xy_ptr + 2*g + 0, v_xy_local.x);
                atomicAdd(v_xy_ptr + 2*g + 1, v_xy_local.y);

                float* v_log_scales_ptr = (float*)(v_log_scales);
                atomicAdd(v_log_scales_ptr + 2*g + 0, v_log_scales_local.x);
                atomicAdd(v_log_scales_ptr + 2*g + 1, v_log_scales_local.y);

                atomicAdd(v_thetas + g, v_thetas_local);

                float* v_sig_k_ptr = (float*)(v_sig_k);
                atomicAdd(v_sig_k_ptr + 2*g + 0, v_sig_k_local.x);
                atomicAdd(v_sig_k_ptr + 2*g + 1, v_sig_k_local.y);

                atomicAdd(v_betas + g, v_betas_local);
            }
        }
    }
}

