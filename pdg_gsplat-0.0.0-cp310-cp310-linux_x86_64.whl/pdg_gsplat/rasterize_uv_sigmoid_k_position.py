"""Python bindings for custom Cuda functions"""

from typing import Optional, Tuple
import torch
from jaxtyping import Float, Int
from torch import Tensor
from torch.autograd import Function

import pdg_gsplat.cuda as _C

from .utils import bin_and_sort_gaussians, compute_cumulative_intersects


def bin_and_sort_gaussians_my(
        means2d: Float[Tensor, "*batch 2"],
        extents: Float[Tensor, "*batch 2"],
        num_tiles_hit: Int[Tensor, "*batch 1"],
        img_height: int,
        img_width: int,
        block_width: int,
) -> Tuple[
    Float[Tensor, "num_intersects 1"],
    Float[Tensor, "num_intersects 2"],
]:
    num_points = means2d.size(0)
    tile_bounds = (
        (img_width + block_width - 1) // block_width,
        (img_height + block_width - 1) // block_width,
        1,
    )

    depths = torch.zeros_like(means2d[..., 0], device=means2d.device)

    num_intersects, cum_tiles_hit = compute_cumulative_intersects(num_tiles_hit)

    (
        isect_ids_unsorted,
        gaussian_ids_unsorted,
        isect_ids_sorted,
        gaussian_ids_sorted,
        tile_bins,
    ) = bin_and_sort_gaussians(
        num_points,
        num_intersects,
        means2d,
        depths,
        extents,
        cum_tiles_hit,
        tile_bounds,
        block_width,
    )
    return gaussian_ids_sorted, tile_bins


def rasterize_gaussians_position(
    means2d: Float[Tensor, "*batch 2"],
    log_scales: Float[Tensor, "*batch 2"],
    thetas: Float[Tensor, "*batch 1"],
    sig_k: Float[Tensor, "*batch 2"],
    colors: Float[Tensor, "*batch channels"],
    extents: Float[Tensor, "*batch 2"],
    num_tiles_hit: Int[Tensor, "*batch 1"],
    pxs: Float[Tensor, "*batch 1"],
    pys: Float[Tensor, "*batch 1"],
    img_height: int,
    img_width: int,
    block_width: int,
    gaussian_ids_sorted: Int[Tensor, "*batch 1"],
    tile_bins: Int[Tensor, "*batch 1"],
) -> Tensor:
    
    assert block_width > 1 and block_width <= 16, "block_width must be between 2 and 16"
    if colors.dtype == torch.uint8:
        colors = colors.float() / 255

    if means2d.ndimension() != 2 or means2d.size(1) != 2:
        raise ValueError("means2d must have dimensions (N, 2)")

    if log_scales.ndimension() != 2 or log_scales.size(1) != 2:
        raise ValueError("log_scales must have dimensions (N, 2)")

    if thetas.ndimension() != 2 or thetas.size(1) != 1:
        raise ValueError("thetas must have dimensions (N, 1)")

    if sig_k.ndimension() != 2 or sig_k.size(1) != 2:
        raise ValueError("sig_k must have dimensions (N, 2)")

    if colors.ndimension() != 2:
        raise ValueError("colors must have dimensions (N, D)")

    return _RasterizeGaussiansPosition.apply(
        means2d.contiguous(),
        log_scales.contiguous(),
        thetas.contiguous(),
        sig_k.contiguous(),
        colors.contiguous(),
        extents.contiguous(),
        num_tiles_hit.contiguous(),
        pxs.contiguous(),
        pys.contiguous(),
        img_height,
        img_width,
        block_width,
        gaussian_ids_sorted.contiguous(),
        tile_bins.contiguous(),
    )


class _RasterizeGaussiansPosition(Function):
    """Rasterizes 2D gaussians"""

    @staticmethod
    def forward(
        ctx,
        means2d: Float[Tensor, "*batch 2"],
        log_scales: Float[Tensor, "*batch 2"],
        thetas: Float[Tensor, "*batch 1"],
        sig_k: Float[Tensor, "*batch 2"],
        colors: Float[Tensor, "*batch channels"],
        extents: Float[Tensor, "*batch 2"],
        num_tiles_hit: Int[Tensor, "*batch 1"],
        pxs: Float[Tensor, "*batch 1"],
        pys: Float[Tensor, "*batch 1"],
        img_height: int,
        img_width: int,
        block_width: int,
        gaussian_ids_sorted: Int[Tensor, "*batch 1"],
        tile_bins: Int[Tensor, "*batch 1"],
    ) -> Tensor:

        tile_bounds = (
            (img_width + block_width - 1) // block_width,
            (img_height + block_width - 1) // block_width,
            1,
        )
        block = (block_width, block_width, 1)

        rasterize_fn = _C.rasterize_position_forward

        out_img, final_idx = rasterize_fn(
            tile_bounds,
            block,
            gaussian_ids_sorted,
            tile_bins,
            means2d,
            log_scales,
            thetas,
            sig_k,
            colors,
            pxs,
            pys,
        )

        ctx.tile_bounds = tile_bounds
        ctx.block = block
        ctx.save_for_backward(
            gaussian_ids_sorted,
            tile_bins,
            means2d,
            log_scales,
            thetas,
            sig_k,
            colors,
            pxs,
            pys,
            final_idx
        )

        return out_img

    @staticmethod
    def backward(ctx, v_out_img):
        tile_bounds = ctx.tile_bounds
        block = ctx.block
        (
            gaussian_ids_sorted,
            tile_bins,
            means2d,
            log_scales,
            thetas,
            sig_k,
            colors,
            pxs,
            pys,
            final_idx
        ) = ctx.saved_tensors

        rasterize_fn = _C.rasterize_position_backward

        v_xy, v_log_scales, v_thetas, v_sig_k, v_colors = rasterize_fn(
            tile_bounds,
            block,
            gaussian_ids_sorted,
            tile_bins,
            means2d,
            log_scales,
            thetas,
            sig_k,
            colors,
            pxs,
            pys,
            final_idx,
            v_out_img,
        )

        return (
            v_xy,  # means2d
            v_log_scales,  # log_scales
            v_thetas,  # thetas
            v_sig_k,  # sig_k
            v_colors,  # colors
            None,  # extents
            None,  # num_tiles_hit
            None,  # pxs
            None,  # pys
            None,  # img_height
            None,  # img_width
            None,  # block_width
            None,  # gaussian_ids_sorted
            None,  # tile_bins
        )
