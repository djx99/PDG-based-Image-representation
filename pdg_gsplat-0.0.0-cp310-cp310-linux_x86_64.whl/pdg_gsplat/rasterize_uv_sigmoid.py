"""Python bindings for custom Cuda functions"""

from typing import Optional, Tuple
import torch
from jaxtyping import Float, Int
from torch import Tensor
from torch.autograd import Function

import pdg_gsplat.cuda as _C

from .utils import bin_and_sort_gaussians, compute_cumulative_intersects

def rasterize_gaussians_uv_sigmoid(
    means2d: Float[Tensor, "*batch 2"],
    log_scales: Float[Tensor, "*batch 2"],
    thetas: Float[Tensor, "*batch 1"],
    colors: Float[Tensor, "*batch channels"],
    extents: Float[Tensor, "*batch 2"],
    num_tiles_hit: Int[Tensor, "*batch 1"],
    img_height: int,
    img_width: int,
    block_width: int,
) -> Tensor:
    
    assert block_width > 1 and block_width <= 16, "block_width must be between 2 and 16"
    if colors.dtype == torch.uint8:
        colors = colors.float() / 255

    if means2d.ndimension() != 2 or means2d.size(1) != 2:
        raise ValueError("means2d must have dimensions (N, 2)")

    if log_scales.ndimension() != 2 or log_scales.size(1) != 2:
        raise ValueError("log_scales must have dimensions (N, 2)")

    if thetas.ndimension() != 2 or thetas.size(1) != 1:
        raise ValueError("thetas must have dimensions (N, 1)")

    if colors.ndimension() != 2:
        raise ValueError("colors must have dimensions (N, D)")

    return _RasterizeGaussiansUVSigmoid.apply(
        means2d.contiguous(),
        log_scales.contiguous(),
        thetas.contiguous(),
        colors.contiguous(),
        extents.contiguous(),
        num_tiles_hit.contiguous(),
        img_height,
        img_width,
        block_width,
    )


class _RasterizeGaussiansUVSigmoid(Function):
    """Rasterizes 2D gaussians"""

    @staticmethod
    def forward(
        ctx,
        means2d: Float[Tensor, "*batch 2"],
        log_scales: Float[Tensor, "*batch 2"],
        thetas: Float[Tensor, "*batch 1"],
        colors: Float[Tensor, "*batch channels"],
        extents: Float[Tensor, "*batch 2"],
        num_tiles_hit: Int[Tensor, "*batch 1"],
        img_height: int,
        img_width: int,
        block_width: int,
    ) -> Tensor:
        num_points = means2d.size(0)
        tile_bounds = (
            (img_width + block_width - 1) // block_width,
            (img_height + block_width - 1) // block_width,
            1,
        )
        block = (block_width, block_width, 1)
        img_size = (img_width, img_height, 1)

        depths = torch.zeros_like(means2d[..., 0], device=means2d.device)

        num_intersects, cum_tiles_hit = compute_cumulative_intersects(num_tiles_hit)

        if num_intersects < 1:
            out_img = (
                torch.ones(img_height, img_width, colors.shape[-1], device=means2d.device)
            )
            gaussian_ids_sorted = torch.zeros(0, 1, device=means2d.device)
            tile_bins = torch.zeros(0, 2, device=means2d.device)
            final_idx = torch.zeros(img_height, img_width, device=means2d.device)
        else:
            (
                isect_ids_unsorted,
                gaussian_ids_unsorted,
                isect_ids_sorted,
                gaussian_ids_sorted,
                tile_bins,
            ) = bin_and_sort_gaussians(
                num_points,
                num_intersects,
                means2d,
                depths,
                extents,
                cum_tiles_hit,
                tile_bounds,
                block_width,
            )
            rasterize_fn = _C.rasterize_uv_sigmoid_forward

            out_img, final_idx = rasterize_fn(
                tile_bounds,
                block,
                img_size,
                gaussian_ids_sorted,
                tile_bins,
                means2d,
                log_scales,
                thetas,
                colors,
            )

        ctx.img_width = img_width
        ctx.img_height = img_height
        ctx.num_intersects = num_intersects
        ctx.block_width = block_width
        ctx.save_for_backward(
            gaussian_ids_sorted,
            tile_bins,
            means2d,
            log_scales,
            thetas,
            colors,
            final_idx
        )

        return out_img

    @staticmethod
    def backward(ctx, v_out_img):
        img_height = ctx.img_height
        img_width = ctx.img_width
        num_intersects = ctx.num_intersects

        (
            gaussian_ids_sorted,
            tile_bins,
            means2d,
            log_scales,
            thetas,
            colors,
            final_idx
        ) = ctx.saved_tensors

        if num_intersects < 1:
            v_xy = torch.zeros_like(means2d)
            v_log_scales = torch.zeros_like(log_scales)
            v_thetas = torch.zeros_like(thetas)
            v_colors = torch.zeros_like(colors)

        else:
            rasterize_fn = _C.rasterize_uv_sigmoid_backward

            v_xy, v_log_scales, v_thetas, v_colors = rasterize_fn(
                img_height,
                img_width,
                ctx.block_width,
                gaussian_ids_sorted,
                tile_bins,
                means2d,
                log_scales,
                thetas,
                colors,
                final_idx,
                v_out_img,
            )

        return (
            v_xy,  # means2d
            v_log_scales,  # log_scales
            v_thetas,  # thetas
            v_colors,  # colors
            None,  # extents
            None,  # num_tiles_hit
            None,  # img_height
            None,  # img_width
            None,  # block_width
        )
