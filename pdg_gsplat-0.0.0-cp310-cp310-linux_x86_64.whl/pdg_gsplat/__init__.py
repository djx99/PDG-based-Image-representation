from typing import Any
import torch
from .project_gaussians import project_gaussians
from .rasterize import rasterize_gaussians
from .rasterize_sigmoid import rasterize_gaussians_sigmoid
from .rasterize_uv import rasterize_gaussians_uv
from .rasterize_uv_sigmoid import rasterize_gaussians_uv_sigmoid
from .rasterize_uv_sigmoid_k import rasterize_gaussians_uv_sigmoid_k
from .rasterize_uv_sigmoid_k_beta import rasterize_gaussians_uv_sigmoid_k_beta
from .rasterize_uv_sigmoid_k_position import rasterize_gaussians_position
from .rasterize_uv_sigmoid_k_position import bin_and_sort_gaussians_my
from .rasterize_uv_sigmoid_k_randpos import rasterize_gaussians_uv_sigmoid_k_randpos
from .project_gaussians_uv import project_gaussians_uv
from .utils import (
    map_gaussian_to_intersects,
    bin_and_sort_gaussians,
    compute_cumulative_intersects,
    compute_cov2d_bounds,
    get_tile_bin_edges,
)
from .version import __version__
import warnings


__all__ = [
    "__version__",
    "project_gaussians",
    "rasterize_gaussians",
    "bin_and_sort_gaussians",
    "compute_cumulative_intersects",
    "compute_cov2d_bounds",
    "get_tile_bin_edges",
    "map_gaussian_to_intersects",
    "ProjectGaussians",
    "RasterizeGaussians",
    "BinAndSortGaussians",
    "ComputeCumulativeIntersects",
    "ComputeCov2dBounds",
    "GetTileBinEdges",
    "MapGaussiansToIntersects",

    "rasterize_gaussians_sigmoid",
    "RasterizeGaussiansSigmoid",

    "rasterize_gaussians_uv",
    "RasterizeGaussiansUV",

    "project_gaussians_uv",

    "rasterize_gaussians_uv_sigmoid",
    "RasterizeGaussiansUVSigmoid",

    "rasterize_gaussians_uv_sigmoid_k",
    "RasterizeGaussiansUVSigmoidK",

    "rasterize_gaussians_position",
    "bin_and_sort_gaussians_my",

    "rasterize_gaussians_uv_sigmoid_k_randpos",

    "rasterize_gaussians_uv_sigmoid_k_beta",
    "RasterizeGaussiansUVSigmoidKBeta",
]

# Define these for backwards compatibility


class MapGaussiansToIntersects(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "MapGaussiansToIntersects is deprecated, use map_gaussian_to_intersects instead",
            DeprecationWarning,
        )
        return map_gaussian_to_intersects(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class ComputeCumulativeIntersects(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "ComputeCumulativeIntersects is deprecated, use compute_cumulative_intersects instead",
            DeprecationWarning,
        )
        return compute_cumulative_intersects(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class ComputeCov2dBounds(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "ComputeCov2dBounds is deprecated, use compute_cov2d_bounds instead",
            DeprecationWarning,
        )
        return compute_cov2d_bounds(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class GetTileBinEdges(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "GetTileBinEdges is deprecated, use get_tile_bin_edges instead",
            DeprecationWarning,
        )
        return get_tile_bin_edges(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class BinAndSortGaussians(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "BinAndSortGaussians is deprecated, use bin_and_sort_gaussians instead",
            DeprecationWarning,
        )
        return bin_and_sort_gaussians(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class ProjectGaussians(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "ProjectGaussians is deprecated, use project_gaussians instead",
            DeprecationWarning,
        )
        return project_gaussians(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class RasterizeGaussians(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "RasterizeGaussians is deprecated, use rasterize_gaussians instead",
            DeprecationWarning,
        )
        return rasterize_gaussians(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class RasterizeGaussiansSigmoid(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "RasterizeGaussiansSigmoid is deprecated, use rasterize_gaussians_sigmoid instead",
            DeprecationWarning,
        )
        return rasterize_gaussians_sigmoid(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class RasterizeGaussiansUV(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "RasterizeGaussiansUV is deprecated, use rasterize_gaussians_uv instead",
            DeprecationWarning,
        )
        return rasterize_gaussians_uv(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError


class RasterizeGaussiansUVSigmoid(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "RasterizeGaussiansUVSigmoid is deprecated, use rasterize_gaussians_uv_sigmoid instead",
            DeprecationWarning,
        )
        return rasterize_gaussians_uv_sigmoid(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError

class RasterizeGaussiansUVSigmoidK(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "RasterizeGaussiansUVSigmoidK is deprecated, use rasterize_gaussians_uv_sigmoid_k instead",
            DeprecationWarning,
        )
        return rasterize_gaussians_uv_sigmoid_k(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError

class RasterizeGaussiansUVSigmoidKBeta(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *args, **kwargs):
        warnings.warn(
            "RasterizeGaussiansUVSigmoidKBeta is deprecated, use rasterize_gaussians_uv_sigmoid_k_beta instead",
            DeprecationWarning,
        )
        return rasterize_gaussians_uv_sigmoid_k_beta(*args, **kwargs)

    @staticmethod
    def backward(ctx: Any, *grad_outputs: Any) -> Any:
        raise NotImplementedError