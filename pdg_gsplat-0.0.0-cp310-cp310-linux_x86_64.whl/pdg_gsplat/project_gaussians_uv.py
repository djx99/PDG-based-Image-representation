"""Python bindings for 2D gaussian projection"""

from typing import Optional, Tuple
import torch

from jaxtyping import Float
from torch import Tensor

import pdg_gsplat.cuda as _C


def project_gaussians_uv(
    cov2d: Float[Tensor, "*batch 3"],
    means2d: Float[Tensor, "*batch 2"],
    img_height: int,
    img_width: int,
    block_width: int
) -> Tuple[Tensor, Tensor]:
    assert block_width > 1 and block_width <= 16, "block_width must be between 2 and 16"
    num_points = cov2d.shape[-2]
    if num_points < 1 or cov2d.shape[-1] != 3:
        raise ValueError(f"Invalid shape for cov2d: {cov2d.shape}")

    (
        xys,
        extents,
        conics,
        num_tiles_hit,
    ) = _C.project_gaussians_forward(
        num_points,
        cov2d,
        means2d,
        None,
        img_height,
        img_width,
        block_width,
    )

    return (extents, num_tiles_hit)
